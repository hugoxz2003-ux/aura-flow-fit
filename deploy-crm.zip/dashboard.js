// Dashboard JavaScript

// ==========================================
// DEMO FALLBACK DATA (used when Supabase is unreachable)
// ==========================================
const DEMO_MEMBERS = [
    { id: 1, nombre: 'Ana García', email: 'ana@example.com', plan: 'Pilates 2x Semanal', estado: 'Activo', clases_restantes: 8, fecha_vencimiento: '2026-04-30' },
    { id: 2, nombre: 'Laura Torres', email: 'laura@example.com', plan: 'Pilates 3x Semanal', estado: 'Activo', clases_restantes: 12, fecha_vencimiento: '2026-04-30' },
    { id: 3, nombre: 'Sofía Ramos', email: 'sofia@example.com', plan: 'Plan Gimnasio', estado: 'Activo', clases_restantes: 999, fecha_vencimiento: '2026-05-15' },
    { id: 4, nombre: 'Carlos Mendoza', email: 'carlos@example.com', plan: 'Pilates 1x Semanal', estado: 'Vencido', clases_restantes: 0, fecha_vencimiento: '2026-02-28' },
    { id: 5, nombre: 'María Soto', email: 'maria@example.com', plan: 'Pilates 4x Semanal', estado: 'Activo', clases_restantes: 16, fecha_vencimiento: '2026-04-15' }
];

const DEMO_CLASSES = [
    { id: 1, nombre: 'Pilates Reformer', instructor: 'María González', horario: '09:00:00', tipo: 'pilates', cupos_ocupados: 7, cupos_max: 8 },
    { id: 2, nombre: 'Pilates Reformer', instructor: 'María González', horario: '11:00:00', tipo: 'pilates', cupos_ocupados: 4, cupos_max: 8 },
    { id: 3, nombre: 'Pilates Reformer', instructor: 'María González', horario: '18:00:00', tipo: 'pilates', cupos_ocupados: 6, cupos_max: 8 },
    { id: 4, nombre: 'Entrenamiento Funcional', instructor: 'Carlos Ruiz', horario: '08:00:00', tipo: 'gym', cupos_ocupados: 12, cupos_max: 20 },
    { id: 5, nombre: 'Yoga Flow', instructor: 'Valeria Paz', horario: '10:00:00', tipo: 'grupal', cupos_ocupados: 8, cupos_max: 15 }
];

const DEMO_LEADS = [
    { id: 1, nombre: 'Juan Pérez', email: 'juan@prospecto.cl', phone: '+56912345678', source: 'Instagram', status: 'Nuevo' },
    { id: 2, nombre: 'Clara Soto', email: 'clara@prospecto.cl', phone: '+56987654321', source: 'Web', status: 'Contactado' },
    { id: 3, nombre: 'Diego Ríos', email: 'diego@prospecto.cl', phone: '+56955566677', source: 'Recomendación', status: 'Interesado' },
    { id: 4, nombre: 'Fernanda Lagos', email: 'fernanda@prospecto.cl', phone: '+56933344455', source: 'Instagram', status: 'Nuevo' }
];

const DEMO_FINANCES = [
    { id: 1, description: 'Pilates 2x - Ana García', amount: 65000, status: 'Pagado', payment_method: 'Transferencia', created_at: '2026-03-15T10:00:00Z' },
    { id: 2, description: 'Pilates 3x - Laura Torres', amount: 85000, status: 'Pagado', payment_method: 'Débito', created_at: '2026-03-14T15:30:00Z' },
    { id: 3, description: 'Plan Gimnasio - Sofía Ramos', amount: 35000, status: 'Pagado', payment_method: 'Efectivo', created_at: '2026-03-10T09:00:00Z' },
    { id: 4, description: 'Pilates 4x - María Soto', amount: 105000, status: 'Pagado', payment_method: 'Transferencia', created_at: '2026-03-01T11:00:00Z' }
];

function loadDemoData() {
    dashboardData.members = DEMO_MEMBERS;
    dashboardData.classes = DEMO_CLASSES;
    dashboardData.leads = DEMO_LEADS;
    dashboardData.finances = DEMO_FINANCES;
    dashboardData.bookings = [];
    dashboardData.waitlist = [];
    console.log('Using demo data (Supabase not reachable from file:// protocol)');
}

// Data state
let dashboardData = {
    members: [],
    leads: [],
    finances: [],
    classes: [],
    bookings: [],
    waitlist: []
};

// Fetch real data from Supabase
async function fetchDashboardData() {
    try {
        const { data: members, error } = await supabase
            .from('socios')
            .select('*');

        if (error) throw error;
        dashboardData.members = members;

        // Fetch classes
        const { data: classes, error: errorClasses } = await supabase
            .from('clases')
            .select('*');

        if (errorClasses) throw errorClasses;
        dashboardData.classes = classes;

        // Fetch leads
        const { data: leads } = await supabase.from('leads').select('*');
        if (leads) dashboardData.leads = leads;

        // Fetch ALL Bookings
        const { data: bookings } = await supabase
            .from('reservas')
            .select('*, socio:socios(*), clase:clases(*)')
            .order('created_at', { ascending: false });

        if (bookings) dashboardData.bookings = bookings;

        // Fetch Waitlist (NEW)
        const { data: waitlist } = await supabase
            .from('lista_espera')
            .select('*, socio:socios(*), clase:clases(*)')
            .order('created_at', { ascending: true });

        dashboardData.waitlist = waitlist || [];

        // Fetch Finances (Transactions)
        const { data: finances } = await supabase
            .from('transactions')
            .select('*')
            .order('created_at', { ascending: false });
        dashboardData.finances = finances || [];

        console.log('Real data fetched from Supabase:', dashboardData);

        // Refresh active section
        const activeSection = document.querySelector('.nav-item.active');
        if (activeSection) {
            const sectionTarget = activeSection.getAttribute('href').substring(1);
            showSection(sectionTarget);
        }

        renderRecentBookings();
        updateKPIs();
    } catch (err) {
        console.error('Error fetching data from Supabase:', err);
        console.warn('Loading demo data as fallback...');
        loadDemoData();
        // Still render with demo data
        const activeSection = document.querySelector('.nav-item.active');
        if (activeSection) {
            const sectionTarget = activeSection.getAttribute('href').substring(1);
            showSection(sectionTarget);
        }
        renderRecentBookings();
        updateKPIs();
    }
}

function renderRecentBookings() {
    const list = document.getElementById('recent-bookings-list');
    if (!list || !dashboardData.bookings) return;

    if (dashboardData.bookings.length === 0) {
        list.innerHTML = '<p class="p-lg text-muted text-center">No hay reservas registradas aún.</p>';
        return;
    }

    // Take last 5
    const recent = dashboardData.bookings.slice(0, 5);

    list.innerHTML = recent.map(b => `
        <div class="booking-item">
            <div class="booking-info">
                <div class="booking-avatar">${b.socio.nombre.charAt(0)}</div>
                <div class="booking-details">
                    <h4>${b.socio.nombre}</h4>
                    <p>${b.clase.nombre} • ${b.clase.horario.substring(0, 5)}</p>
                </div>
            </div>
            <div class="flex flex-col items-end">
                <span class="plan-badge plan-${b.socio.plan.toLowerCase().replace(' ', '-')}">${b.socio.plan}</span>
                <span class="text-xs text-muted mt-xs">${new Date(b.created_at).toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' })}</span>
            </div>
        </div>
    `).join('');
}

// Keep DUMMY for modules not yet connected
const DUMMY_DATA = {
    plans: {
        pilates: [
            { id: 'p1', name: 'Mensual 1x', price: 45000, freq: 1, duration: 1 },
            { id: 'p2', name: 'Mensual 2x', price: 65000, freq: 2, duration: 1 },
            { id: 'p3', name: 'Mensual 3x', price: 85000, freq: 3, duration: 1 },
            { id: 'p4', name: 'Mensual 4x', price: 105000, freq: 4, duration: 1 },
            { id: 'p5', name: 'Trimestral 2x', price: 180000, freq: 2, duration: 3 },
            { id: 'p6', name: 'Semestral 2x', price: 330000, freq: 2, duration: 6 }
        ],
        gym: [
            { id: 'g1', name: 'Mensual', price: 35000, duration: 1 },
            { id: 'g2', name: 'Trimestral', price: 90000, duration: 3 },
            { id: 'g3', name: 'Semestral', price: 160000, duration: 6 }
        ]
    },
    leads: [
        { id: 1, name: 'Juan Pérez', email: 'juan@prospecto.cl', phone: '+56912345678', source: 'Instagram', status: 'Nuevo' },
        { id: 2, name: 'Clara Soto', email: 'clara@prospecto.cl', phone: '+56987654321', source: 'Web', status: 'Contactado' },
        { id: 3, name: 'Diego Ríos', email: 'diego@prospecto.cl', phone: '+56955566677', source: 'Recomendación', status: 'Interesado' }
    ],
    finances: [
        { id: 1, concept: 'Membresía María G.', amount: 65000, type: 'Ingreso', date: '2024-02-15' },
        { id: 2, concept: 'Pago Instructor Carlos', amount: -400000, type: 'Egreso', date: '2024-02-14' },
        { id: 3, concept: 'Venta Agua Mineral', amount: 1500, type: 'Ingreso', date: '2024-02-14' }
    ]
};

// Initialize charts when DOM is loaded
document.addEventListener('DOMContentLoaded', function () {
    const user = window.getCurrentUser ? window.getCurrentUser() : null;
    if (user) {
        applyRoleAccess(user.role);
        const greeting = document.querySelector('.page-subtitle');
        if (greeting) greeting.textContent = `Bienvenido de vuelta, ${user.name}`;

        const headerName = document.querySelector('.user-name');
        if (headerName) headerName.textContent = user.name;
    }

    initializeCharts();
    setupEventListeners();
    fetchDashboardData();
    // Start at Home
    showSection('dashboard');
});

function applyRoleAccess(role) {
    console.log('Applying access for role:', role);
    
    const navIds = ['nav-dashboard', 'nav-calendar', 'nav-plans', 'nav-members', 'nav-leads', 'nav-finances', 'nav-evaluations', 'nav-attendance', 'nav-comunicacion', 'nav-settings'];
    
    navIds.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.display = 'flex';
    });

    const staffHidden = [
        'nav-plans',
        'nav-finances',
        'nav-leads',
        'nav-settings',
        'nav-comunicacion'
    ];

    if (role === 'staff' || role === 'coach' || role === 'usuario') {
        staffHidden.forEach(id => {
            const el = document.getElementById(id);
            if (el) el.style.display = 'none';
        });
        
        const revenueCard = document.querySelector('.kpi-card:nth-child(1)');
        if (revenueCard) revenueCard.style.display = 'none';
        const leadsCard = document.querySelector('.kpi-card:nth-child(4)');
        if (leadsCard) leadsCard.style.display = 'none';
    } else if (role === 'admin') {
        const el = document.getElementById('nav-settings');
        if (el) el.style.display = 'none';
    }
}

window.applyRoleAccess = applyRoleAccess;


let revenueChartInstance = null;
let occupancyChartInstance = null;
window.revenueChartInstance = null; // exposed for period filter
window.dashboardData = dashboardData; // expose for inline scripts

function initializeCharts() {
    // Generate real revenue data simply from current year
    const currentYear = new Date().getFullYear();
    const monthlyData = new Array(12).fill(0);

    if (dashboardData.finances && dashboardData.finances.length > 0) {
        dashboardData.finances.forEach(f => {
            if ((f.status === 'success' || f.status === 'Pagado') && f.amount > 0) {
                const date = new Date(f.created_at);
                if (date.getFullYear() === currentYear) {
                    monthlyData[date.getMonth()] += Number(f.amount);
                }
            }
        });
    }
    const dataInMillions = monthlyData.map(val => val > 0 ? (val / 1000000).toFixed(2) : 0);
    const targetData = [8, 8, 8.5, 8.5, 9, 9, 9.5, 9.5, 10, 10, 10.5, 10.5]; // Example static target

    // Revenue Chart
    const revenueCtx = document.getElementById('revenueChart');
    if (revenueCtx) {
        if (revenueChartInstance) revenueChartInstance.destroy();
        revenueChartInstance = new Chart(revenueCtx, {
            type: 'bar',
            data: {
                labels: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'],
                datasets: [
                    {
                        label: 'Ingresos',
                        data: dataInMillions,
                        backgroundColor: 'rgba(6, 182, 212, 0.8)',
                        borderColor: '#06B6D4',
                        borderWidth: 2,
                        borderRadius: 8,
                    },
                    {
                        label: 'Objetivo',
                        data: targetData,
                        type: 'line',
                        borderColor: '#22C55E',
                        backgroundColor: 'transparent',
                        borderWidth: 3,
                        pointRadius: 0,
                        pointHoverRadius: 6,
                        tension: 0.4,
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top',
                        labels: {
                            color: '#D4D4D8',
                            font: { family: 'Inter', size: 12 },
                            usePointStyle: true,
                            padding: 20
                        }
                    },
                    tooltip: {
                        backgroundColor: '#27272A',
                        titleColor: '#FAFAFA',
                        bodyColor: '#D4D4D8',
                        borderColor: 'rgba(6, 182, 212, 0.2)',
                        borderWidth: 1,
                        padding: 12,
                        callbacks: {
                            label: function (context) {
                                return context.dataset.label + ': $' + context.parsed.y + 'M';
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { color: 'rgba(255, 255, 255, 0.05)', drawBorder: false },
                        ticks: {
                            color: '#A1A1AA',
                            font: { family: 'Inter', size: 11 },
                            callback: function (value) { return '$' + value + 'M'; }
                        }
                    },
                    x: {
                        grid: { display: false, drawBorder: false },
                        ticks: { color: '#A1A1AA', font: { family: 'Inter', size: 11 } }
                    }
                }
            }
        });
        window.revenueChartInstance = revenueChartInstance; // expose for chart period filter
    }

    // Occupancy Donut Chart (Real data based on Class types)
    let countReformer = 0;
    let countPersonal = 0;
    let countGrupal = 0;

    if (dashboardData.classes && dashboardData.classes.length > 0) {
        dashboardData.classes.forEach(c => {
            if (c.tipo === 'pilates' || c.nombre.toLowerCase().includes('reformer')) countReformer += c.cupos_ocupados || 0;
            else if (c.tipo === 'personal' || c.nombre.toLowerCase().includes('personal')) countPersonal += c.cupos_ocupados || 0;
            else countGrupal += c.cupos_ocupados || 0; // Default to grupal
        });
    }

    // Fallback if no data
    if (countReformer === 0 && countPersonal === 0 && countGrupal === 0) {
        countReformer = 65; countPersonal = 25; countGrupal = 10;
    }

    const occupancyCtx = document.getElementById('occupancyChart');
    if (occupancyCtx) {
        if (occupancyChartInstance) occupancyChartInstance.destroy();
        occupancyChartInstance = new Chart(occupancyCtx, {
            type: 'doughnut',
            data: {
                labels: ['Reformer', 'Personal', 'Grupal'],
                datasets: [{
                    data: [countReformer, countPersonal, countGrupal],
                    backgroundColor: ['#06B6D4', '#22C55E', '#F59E0B'],
                    borderWidth: 0,
                    hoverOffset: 10
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '70%',
                plugins: {
                    legend: {
                        display: true,
                        position: 'bottom',
                        labels: {
                            color: '#D4D4D8',
                            font: { family: 'Inter', size: 12 },
                            padding: 20,
                            usePointStyle: true
                        }
                    }
                }
            }
        });
    }
}

function setupEventListeners() {
    // Navigation
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        item.addEventListener('click', function (e) {
            e.preventDefault();
            const sectionTarget = this.getAttribute('href').substring(1);
            showSection(sectionTarget);

            navItems.forEach(nav => nav.classList.remove('active'));
            this.classList.add('active');
        });
    });

    // Search functionality
    const searchInput = document.querySelector('.search-input');
    if (searchInput) {
        searchInput.addEventListener('input', function (e) {
            const searchTerm = e.target.value.toLowerCase();
            console.log('Searching for:', searchTerm);
        });
    }

    // Mobile sidebar toggle
    const sidebar = document.querySelector('.sidebar');
    const menuToggle = document.getElementById('mobile-menu-toggle');

    if (menuToggle && sidebar) {
        menuToggle.addEventListener('click', () => {
            sidebar.classList.toggle('open');
        });
    }

    // Close sidebar on navigation (mobile)
    navItems.forEach(item => {
        item.addEventListener('click', () => {
            if (window.innerWidth <= 768) {
                sidebar.classList.remove('open');
            }
        });
    });

    // Check-in Buttons
    document.addEventListener('click', async (e) => {
        if (e.target.matches('.btn-primary.btn-sm') && e.target.textContent === 'Check-in') {
            const row = e.target.closest('tr');
            const classTime = row.cells[0].textContent;
            const className = row.cells[1].textContent;

            // In a real app, we'd need the class ID and socio ID.
            // For now, we'll simulate the update on the first class found in dashboardData.classes
            const classObj = dashboardData.classes.find(c => c.nombre === className && c.horario.startsWith(classTime));

            if (confirm(`¿Registrar asistencia para ${className}?`)) {
                try {
                    e.target.textContent = 'Procesando...';

                    // Here you would typically link this to a 'reservas' record.
                    // For demo, we just show the UI success.
                    setTimeout(() => {
                        e.target.textContent = 'Registrado ✅';
                        e.target.classList.replace('btn-primary', 'btn-success');
                        e.target.style.pointerEvents = 'none';
                    }, 500);
                } catch (err) {
                    console.error('Check-in error:', err);
                    e.target.textContent = 'Error';
                }
            }
        }

        // New Member Button
        if (e.target.matches('.btn-primary.btn-sm') && e.target.textContent === '+ Nuevo Socio') {
            const nombre = prompt('Nombre del nuevo socio:');
            const email = prompt('Email del nuevo socio:');

            if (nombre && email) {
                try {
                    const { error } = await supabase
                        .from('socios')
                        .insert([{ nombre, email, plan: 'Plan Premium', estado: 'Activo', clases_restantes: 8 }]);

                    if (error) throw error;
                    alert('Socio registrado con éxito');
                    fetchDashboardData(); // Refresh list
                } catch (err) {
                    alert('Error al registrar socio: ' + err.message);
                }
            }
        }
    });
}

function showSection(sectionId) {
    const mainContent = document.querySelector('.main-content');
    const pageTitle = document.querySelector('.page-title');
    const kpiGrid = document.querySelector('.kpi-grid');
    const chartsRow = document.querySelector('.charts-row');
    const alertsSection = document.querySelector('.alerts-section');
    const todayClasses = document.querySelector('.today-classes-section');

    // Remove any existing dynamic content
    const existingDynamic = document.getElementById('dynamic-content');
    if (existingDynamic) existingDynamic.remove();

    if (sectionId === 'dashboard') {
        kpiGrid.style.display = 'grid';
        chartsRow.style.display = 'grid';
        alertsSection.style.display = 'block';
        todayClasses.style.display = 'block';
        pageTitle.textContent = 'Dashboard';
        renderTodayClasses();
        updateKPIs();

        // Re-initialize charts to fix "shifted" or zero-size issues when switching views
        setTimeout(initializeCharts, 100);
        return;
    }

    // ... other functions ...

    function renderTodayClasses() {
        const tbody = document.getElementById('today-classes-body');
        if (!tbody) return;

        if (dashboardData.classes.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="text-center p-lg">No hay clases programadas para hoy.</td></tr>';
            return;
        }

        tbody.innerHTML = dashboardData.classes.map(c => {
            const max = c.tipo === 'pilates' ? 10 : 50;
            const percent = Math.min(100, Math.round((c.cupos_ocupados / max) * 100));
            const inWaitlist = dashboardData.waitlist.filter(w => w.clase_id === c.id).length;

            return `
            <tr>
                <td>${c.horario.substring(0, 5)}</td>
                <td>
                    <div class="flex flex-col">
                        <span class="font-600">${c.nombre}</span>
                        <span class="text-xs ${c.tipo === 'pilates' ? 'text-primary' : 'text-success'} uppercase font-700">${c.tipo}</span>
                    </div>
                </td>
                <td>${c.instructor}</td>
                <td>
                    <div class="occupancy-bar">
                        <div class="occupancy-fill ${percent >= 100 ? 'bg-error' : ''}" style="width: ${percent}%"></div>
                        <span>${c.cupos_ocupados}/${max}</span>
                    </div>
                    ${inWaitlist > 0 ? `<span class="text-xs text-warning font-600">⌛ ${inWaitlist} en espera</span>` : ''}
                </td>
                <td>
                    <button class="btn btn-primary btn-sm" onclick="handleCheckIn('${c.id}', '${c.nombre}')">Check-in</button>
                    ${inWaitlist > 0 ? `<button class="btn btn-secondary btn-sm" onclick="showSection('waitlist')">Ver Lista</button>` : ''}
                </td>
            </tr>
        `;
        }).join('');
    }

    function updateKPIs() {
        const formatter = new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP', minimumFractionDigits: 0 });

        // 1. Ingresos del Mes
        const currentMonthStr = new Date().toISOString().slice(0, 7);
        const monthlyIncome = dashboardData.finances
            .filter(f => (f.status === 'success' || f.status === 'Pagado') && f.amount > 0 && f.created_at.startsWith(currentMonthStr))
            .reduce((sum, f) => sum + Number(f.amount), 0);
        const incomeKpi = document.querySelector('.kpi-card:nth-child(1) .kpi-value');
        if (incomeKpi) incomeKpi.textContent = (monthlyIncome / 1000000).toFixed(1) + 'M';

        // 2. Socios Activos
        const activeMembers = dashboardData.members.filter(m => m.estado === 'Activo').length;
        const membersKpi = document.querySelector('.kpi-card:nth-child(2) .kpi-value');
        if (membersKpi) membersKpi.textContent = activeMembers;

        // 3. Ocupación Promedio
        const totalOccupied = dashboardData.classes.reduce((sum, c) => sum + (c.cupos_ocupados || 0), 0);
        const totalMax = dashboardData.classes.reduce((sum, c) => sum + (c.cupos_max || 10), 0);
        const avgOccupancy = totalMax > 0 ? Math.round((totalOccupied / totalMax) * 100) : 0;
        const occKpi = document.querySelector('.kpi-card:nth-child(3) .kpi-value');
        if (occKpi) occKpi.textContent = avgOccupancy + '%';

        // 4. Leads Nuevos
        const newLeads = dashboardData.leads.filter(l => l.status === 'Nuevo').length;
        const leadsKpi = document.querySelector('.kpi-card:nth-child(4) .kpi-value');
        if (leadsKpi) leadsKpi.textContent = newLeads;

        // Resync charts with real data if needed
        setTimeout(initializeCharts, 50);
    }

    // Hide dashboard elements
    kpiGrid.style.display = 'none';
    chartsRow.style.display = 'none';
    alertsSection.style.display = 'none';
    todayClasses.style.display = 'none';

    // Create dynamic content area
    const dynamicContent = document.createElement('div');
    dynamicContent.id = 'dynamic-content';
    mainContent.appendChild(dynamicContent);

    switch (sectionId) {
        case 'members':
            pageTitle.textContent = 'Gestión de Socios';
            renderMembers(dynamicContent);
            break;
        case 'leads':
            pageTitle.textContent = 'Pipeline de Leads';
            renderLeads(dynamicContent);
            break;
        case 'finances':
            pageTitle.textContent = 'Finanzas y Pagos';
            renderFinances(dynamicContent);
            break;
        case 'calendar':
            pageTitle.textContent = 'Calendario de Clases';
            renderCalendar(dynamicContent);
            break;
        case 'plans':
            pageTitle.textContent = 'Gestión de Planes y Precios';
            renderPlans(dynamicContent);
            break;
        case 'waitlist':
            pageTitle.textContent = 'Lista de Espera';
            renderWaitlist(dynamicContent);
            break;
        case 'evaluations':
            pageTitle.textContent = 'Evaluaciones Físicas';
            renderEvaluations(dynamicContent);
            break;
        case 'settings':
            pageTitle.textContent = 'Configuración';
            renderSettings(dynamicContent);
            break;
        case 'attendance':
            pageTitle.textContent = 'Registro de Asistencia';
            renderAttendance(dynamicContent);
            break;
        case 'comunicacion':
            pageTitle.textContent = 'Comunicación';
            renderComunicacion(dynamicContent);
            break;
        default:
            pageTitle.textContent = sectionId.charAt(0).toUpperCase() + sectionId.slice(1);
            dynamicContent.innerHTML = `<div class="card p-xl flex flex-col items-center justify-center">
                <p class="text-xl mb-md">Módulo ${sectionId} en construcción</p>
                <div class="spinner"></div>
            </div>`;
    }
}

function renderMembers(container) {
    const plansData = window.getPlansData ? window.getPlansData() : DUMMY_DATA.plans;
    // Helper to calculate total classes based on frequency (veces/semana) * 4 weeks * duration (meses)
    // If it's a gym plan without frequency, we give it 999 (ilimitado)
    const allPlans = [...plansData.pilates.map(p => ({...p, fallbackClases: p.freq ? (p.freq * 4 * p.duration) : 999})), 
                      ...plansData.gym.map(p => ({...p, fallbackClases: 999}))];

    container.innerHTML = `
        <!-- Add Member Form -->
        <div id="member-form-wrap" style="display:none;" class="glass-card p-xl mb-lg">
            <h4 class="mb-lg" style="color:var(--primary);">Nuevo Socio</h4>
            <form id="member-form" onsubmit="guardarSocio(event)">
                <div class="grid grid-cols-2 gap-md mb-md">
                    <div><label style="display:block;font-size:.8rem;color:var(--text-muted);margin-bottom:4px;">Nombre Completo</label>
                        <input id="ms-nombre" required placeholder="María González" style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;"></div>
                    <div><label style="display:block;font-size:.8rem;color:var(--text-muted);margin-bottom:4px;">Email</label>
                        <input id="ms-email" type="email" required placeholder="maria@email.com" style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;"></div>
                    <div><label style="display:block;font-size:.8rem;color:var(--text-muted);margin-bottom:4px;">Teléfono</label>
                        <input id="ms-tel" placeholder="+569 1234 5678" style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;"></div>
                    <div><label style="display:block;font-size:.8rem;color:var(--text-muted);margin-bottom:4px;">Plan</label>
                        <select id="ms-plan" required style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;">
                            ${allPlans.map(p => `<option value="${p.name}||${p.fallbackClases}">${p.name}</option>`).join('')}
                        </select></div>
                    <div><label style="display:block;font-size:.8rem;color:var(--text-muted);margin-bottom:4px;">Fecha Inicio</label>
                        <input id="ms-inicio" type="date" value="${new Date().toISOString().split('T')[0]}" style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;"></div>
                    <div><label style="display:block;font-size:.8rem;color:var(--text-muted);margin-bottom:4px;">Estado</label>
                        <select id="ms-estado" style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;">
                            <option>Activo</option><option>Inactivo</option><option>Vencido</option>
                        </select></div>
                </div>
                <div class="flex gap-md">
                    <button type="submit" class="btn btn-primary">Guardar Socio</button>
                    <button type="button" class="btn btn-secondary" onclick="document.getElementById('member-form-wrap').style.display='none';">Cancelar</button>
                </div>
            </form>
        </div>

        <!-- List -->
        <div class="glass-card">
            <div class="p-md flex justify-between items-center border-b border-white-05">
                <h3>Lista de Socios (${dashboardData.members.length})</h3>
                <button class="btn btn-primary btn-sm" onclick="document.getElementById('member-form-wrap').style.display='block'; window.scrollTo(0,0);">+ Nuevo Socio</button>
            </div>
            <table>
                <thead><tr><th>Socio</th><th>Plan</th><th>Clases Rest.</th><th>Vencimiento</th><th>Estado</th></tr></thead>
                <tbody>
                    ${dashboardData.members.length === 0 ? '<tr><td colspan="5" class="text-center p-lg">Sin socios registrados</td></tr>' :
            dashboardData.members.map(m => `
                        <tr>
                            <td><div class="flex items-center gap-sm">
                                <div style="width:32px;height:32px;border-radius:50%;background:var(--primary);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.85rem;">${(m.nombre || '?').charAt(0).toUpperCase()}</div>
                                <div><div class="font-600">${m.nombre}</div><div class="text-xs text-muted">${m.email || ''}</div></div>
                            </div></td>
                            <td><span class="plan-badge">${m.plan}</span></td>
                            <td><span style="font-weight:700;color:${m.clases_restantes === 0 ? 'var(--error)' : m.clases_restantes < 4 ? 'var(--warning)' : 'var(--success)'}">${m.clases_restantes === 999 ? '∞' : m.clases_restantes}</span></td>
                            <td>${m.fecha_vencimiento ? new Date(m.fecha_vencimiento + 'T12:00:00').toLocaleDateString('es-CL') : '-'}</td>
                            <td><span class="badge badge-${m.estado === 'Activo' ? 'success' : m.estado === 'Vencido' ? 'error' : 'warning'}">${m.estado}</span></td>
                        </tr>`).join('')}
                </tbody>
            </table>
        </div>`;
}

async function guardarSocio(e) {
    e.preventDefault();
    const [planName, clasesStr] = document.getElementById('ms-plan').value.split('||');
    const inicio = new Date(document.getElementById('ms-inicio').value);
    const venc = new Date(inicio); venc.setMonth(venc.getMonth() + 1);
    const newM = {
        id: Date.now(), nombre: document.getElementById('ms-nombre').value,
        email: document.getElementById('ms-email').value,
        plan: planName, clases_restantes: parseInt(clasesStr),
        estado: document.getElementById('ms-estado').value,
        fecha_vencimiento: venc.toISOString().split('T')[0]
    };
    try {
        const { error } = await supabase.from('socios').insert([{ nombre: newM.nombre, email: newM.email, plan: newM.plan, clases_restantes: newM.clases_restantes, estado: newM.estado, fecha_vencimiento: newM.fecha_vencimiento }]);
        if (error) throw error;
    } catch { /* offline ok */ }
    dashboardData.members.push(newM);
    document.getElementById('member-form-wrap').style.display = 'none';
    document.getElementById('member-form').reset();
    showMemberDashboard(newM.id);
}
window.guardarSocio = guardarSocio;

function showMemberDashboard(memberId) {
    const m = dashboardData.members.find(x => x.id == memberId) || dashboardData.members[dashboardData.members.length-1];
    if(!m) return;
    
    document.querySelectorAll('.nav-item').forEach(nav => nav.classList.remove('active'));
    
    const mainContent = document.querySelector('.main-content');
    const pageTitle = document.querySelector('.page-title');
    pageTitle.textContent = `Dashboard de Socio: ${m.nombre}`;
    
    document.querySelector('.kpi-grid').style.display = 'none';
    document.querySelector('.charts-row').style.display = 'none';
    document.querySelector('.alerts-section').style.display = 'none';
    document.querySelector('.today-classes-section').style.display = 'none';

    let existingDynamic = document.getElementById('dynamic-content');
    if (!existingDynamic) {
        existingDynamic = document.createElement('div');
        existingDynamic.id = 'dynamic-content';
        mainContent.appendChild(existingDynamic);
    }
    
    const asists = JSON.parse(localStorage.getItem('asistencias') || '[]').filter(a => a.socio === m.nombre);
    existingDynamic.innerHTML = `
        <div class="flex items-center justify-between mb-lg">
            <button class="btn btn-secondary btn-sm" onclick="showSection('members')">← Volver a Socios</button>
        </div>
        <div class="grid grid-cols-3 gap-lg mb-lg">
            <div class="glass-card p-xl" style="height: fit-content;">
                <div style="width:60px;height:60px;border-radius:50%;background:var(--primary);display:flex;align-items:center;justify-content:center;font-size:1.5rem;font-weight:700;margin-bottom:1rem;">
                    ${m.nombre.charAt(0).toUpperCase()}
                </div>
                <h3 class="mb-sm">${m.nombre}</h3>
                <p class="text-xs text-muted mb-xs">Email: <span class="text-primary">${m.email || 'No registrado'}</span></p>
                <p class="text-xs text-muted mb-lg">Estado: <span class="badge badge-${m.estado === 'Activo'?'success':m.estado === 'Vencido'?'error':'warning'}">${m.estado}</span></p>
                
                <h4 class="text-xs uppercase text-muted mb-xs">Membresía actual</h4>
                <p class="font-600 mb-xs">${m.plan}</p>
                <p class="text-xs mb-sm">Clases restantes: <span class="font-700 ${m.clases_restantes>2?'text-success':'text-warning'}">${m.clases_restantes === 999 ? 'Ilimitadas' : m.clases_restantes}</span></p>
                <p class="text-xs mb-md">Vencimiento: <span style="color: ${new Date(m.fecha_vencimiento) < new Date() ? 'var(--error)' : 'white'};">${m.fecha_vencimiento ? new Date(m.fecha_vencimiento+'T12:00:00').toLocaleDateString('es-CL') : '-'}</span></p>
                
                <button class="btn btn-primary btn-sm w-full" onclick="alert('Funcionalidad de renovación en desarrollo');">Restablecer / Renovar Plan</button>
            </div>

            <div class="glass-card" style="grid-column:span 2;">
                <div class="p-md border-b border-white-05"><h3>Historial de Asistencia</h3></div>
                <table class="w-full">
                    <thead><tr><th style="text-align:left;">Fecha</th><th style="text-align:left;">Clase</th></tr></thead>
                    <tbody>
                        ${asists.length === 0 ? '<tr><td colspan="2" class="p-lg text-center text-muted">Aún no tiene asistencias registradas.</td></tr>' : 
                            asists.slice().reverse().map(a => `<tr><td class="p-md border-b border-white-05" style="vertical-align: middle;">${new Date(a.fecha+'T12:00:00').toLocaleDateString('es-CL')}</td><td class="p-md border-b border-white-05" style="vertical-align: middle;">${a.clase}</td></tr>`).join('')}
                    </tbody>
                </table>
            </div>
        </div>
    `;
}
window.showMemberDashboard = showMemberDashboard;

function renderLeads(container) {
    const statuses = [
        { key: 'Nuevo', color: '#3B82F6', icon: '🆕' },
        { key: 'Contactado', color: '#F59E0B', icon: '📞' },
        { key: 'Interesado', color: '#8B5CF6', icon: '⭐' },
        { key: 'Convertido', color: '#22C55E', icon: '✅' }
    ];
    container.innerHTML = `
        <!-- Add Lead Form -->
        <div id="lead-form-wrap" style="display:none;" class="glass-card p-lg mb-lg">
            <h4 class="mb-md" style="color:var(--primary);">Nuevo Lead</h4>
            <form id="lead-form" onsubmit="guardarLead(event)">
                <div class="grid grid-cols-4 gap-md mb-md">
                    <input id="ld-nombre" required placeholder="Nombre" style="background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;">
                    <input id="ld-email" placeholder="Email o Teléfono" style="background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;">
                    <select id="ld-source" style="background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;">
                        <option>Instagram</option><option>Web</option><option>Recomendación</option><option>WhatsApp</option><option>Directo</option>
                    </select>
                    <select id="ld-status" style="background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;">
                        <option>Nuevo</option><option>Contactado</option><option>Interesado</option><option>Convertido</option>
                    </select>
                </div>
                <div class="flex gap-md">
                    <button type="submit" class="btn btn-primary btn-sm">Guardar Lead</button>
                    <button type="button" class="btn btn-secondary btn-sm" onclick="document.getElementById('lead-form-wrap').style.display='none';">Cancelar</button>
                </div>
            </form>
        </div>

        <div class="flex justify-between items-center mb-lg">
            <h3>Pipeline de Leads (${dashboardData.leads.length})</h3>
            <button class="btn btn-primary btn-sm" onclick="document.getElementById('lead-form-wrap').style.display='block';">+ Nuevo Lead</button>
        </div>
        <div class="grid grid-cols-4 gap-lg">
            ${statuses.map(s => {
        const leads = dashboardData.leads.filter(l => l.status === s.key);
        return `
                <div style="background:var(--bg-secondary);border-radius:12px;padding:1rem;border-top:3px solid ${s.color};">
                    <div class="flex justify-between items-center mb-md">
                        <h4 style="font-size:.75rem;text-transform:uppercase;letter-spacing:1px;color:${s.color};">${s.icon} ${s.key}</h4>
                        <span style="background:${s.color}22;color:${s.color};border-radius:999px;padding:2px 8px;font-size:.7rem;font-weight:700;">${leads.length}</span>
                    </div>
                    ${leads.length === 0 ? '<p style="font-size:.75rem;color:var(--text-muted);text-align:center;padding:1rem;">Sin leads</p>' :
                leads.map(l => `
                        <div style="background:var(--bg-primary);border-radius:8px;padding:.75rem;margin-bottom:.5rem;border:1px solid rgba(255,255,255,.05);">
                            <div class="flex justify-between">
                                <p style="font-weight:600;font-size:.875rem;">${l.nombre || l.name}</p>
                                <span style="font-size:.65rem;color:var(--text-muted);">${l.created_at ? new Date(l.created_at).toLocaleDateString('es-CL') : 'Hoy'}</span>
                            </div>
                            <p style="font-size:.75rem;color:var(--text-muted);margin:.25rem 0;">${l.email || l.phone || ''}</p>
                            <div class="flex justify-between items-center" style="margin-top:.5rem;">
                                <span style="font-size:.65rem;background:rgba(255,255,255,.07);padding:2px 7px;border-radius:4px;">${l.source || 'Directo'}</span>
                                <select onchange="cambiarEstadoLead(${l.id}, this.value)" style="font-size:.65rem;background:var(--bg-tertiary);border:none;color:var(--text-muted);border-radius:4px;padding:2px 4px;">
                                    ${statuses.map(ss => `<option value="${ss.key}" ${ss.key === l.status ? 'selected' : ''}>${ss.key}</option>`).join('')}
                                </select>
                            </div>
                        </div>`).join('')
            }
                </div>`;
    }).join('')}
        </div>`;
}

async function guardarLead(e) {
    e.preventDefault();
    const lead = { id: Date.now(), nombre: document.getElementById('ld-nombre').value, email: document.getElementById('ld-email').value, source: document.getElementById('ld-source').value, status: document.getElementById('ld-status').value, created_at: new Date().toISOString() };
    try { await supabase.from('leads').insert([{ nombre: lead.nombre, email: lead.email, source: lead.source, status: lead.status }]); } catch { /* offline */ }
    dashboardData.leads.push(lead);
    document.getElementById('lead-form-wrap').style.display = 'none';
    document.getElementById('lead-form').reset();
    showSection('leads');
}

function cambiarEstadoLead(id, newStatus) {
    const lead = dashboardData.leads.find(l => l.id == id);
    if (lead) { lead.status = newStatus; showSection('leads'); }
}
window.guardarLead = guardarLead;
window.cambiarEstadoLead = cambiarEstadoLead;

function renderFinances(container) {
    const fmt = new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP', minimumFractionDigits: 0 });
    const ingresos = dashboardData.finances.filter(f => f.amount > 0).reduce((s, f) => s + Number(f.amount), 0);
    const egresos = dashboardData.finances.filter(f => f.amount < 0).reduce((s, f) => s + Number(f.amount), 0);
    container.innerHTML = `
        <!-- Add Transaction Form -->
        <div id="fin-form-wrap" style="display:none;" class="glass-card p-lg mb-lg">
            <h4 class="mb-md" style="color:var(--primary);">Registrar Cobro / Pago</h4>
            <form id="fin-form" onsubmit="guardarTransaccion(event)">
                <div class="grid grid-cols-3 gap-md mb-md">
                    <div><label style="display:block;font-size:.75rem;color:var(--text-muted);margin-bottom:4px;">Tipo</label>
                        <select id="fin-tipo" style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;">
                            <option value="ingreso">💰 Ingreso (Cobro)</option>
                            <option value="egreso">💸 Egreso (Gasto)</option>
                        </select></div>
                    <div><label style="display:block;font-size:.75rem;color:var(--text-muted);margin-bottom:4px;">Concepto</label>
                        <input id="fin-desc" required placeholder="Membresía, arriendo, etc." style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;"></div>
                    <div><label style="display:block;font-size:.75rem;color:var(--text-muted);margin-bottom:4px;">Monto (CLP)</label>
                        <input id="fin-monto" type="number" required placeholder="65000" style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;"></div>
                    <div><label style="display:block;font-size:.75rem;color:var(--text-muted);margin-bottom:4px;">Método de Pago</label>
                        <select id="fin-metodo" style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;">
                            <option>Transferencia</option><option>Tarjeta Débito</option><option>Tarjeta Crédito</option><option>Efectivo</option><option>Flow.cl</option>
                        </select></div>
                    <div><label style="display:block;font-size:.75rem;color:var(--text-muted);margin-bottom:4px;">Fecha</label>
                        <input id="fin-fecha" type="date" value="${new Date().toISOString().split('T')[0]}" style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;"></div>
                    <div><label style="display:block;font-size:.75rem;color:var(--text-muted);margin-bottom:4px;">Socio (opcional)</label>
                        <select id="fin-socio" style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;">
                            <option value="">Sin asignar</option>
                            ${dashboardData.members.map(m => `<option value="${m.nombre}">${m.nombre}</option>`).join('')}
                        </select></div>
                </div>
                <div class="flex gap-md">
                    <button type="submit" class="btn btn-primary">Registrar</button>
                    <button type="button" class="btn btn-secondary" onclick="document.getElementById('fin-form-wrap').style.display='none';">Cancelar</button>
                </div>
            </form>
        </div>

        <!-- Totals -->
        <div class="grid grid-cols-3 gap-lg mb-lg">
            <div class="card p-lg text-center"><p class="text-muted text-xs mb-sm">INGRESOS TOTALES</p><h3 class="text-success">${fmt.format(ingresos)}</h3></div>
            <div class="card p-lg text-center"><p class="text-muted text-xs mb-sm">EGRESOS TOTALES</p><h3 class="text-error">${fmt.format(Math.abs(egresos))}</h3></div>
            <div class="card p-lg text-center"><p class="text-muted text-xs mb-sm">UTILIDAD NETA</p><h3 style="color:${ingresos + egresos >= 0 ? 'var(--primary)' : 'var(--error)'}">${fmt.format(ingresos + egresos)}</h3></div>
        </div>

        <div class="glass-card">
            <div class="p-md flex justify-between items-center border-b border-white-05">
                <h3>Historial de Transacciones (${dashboardData.finances.length})</h3>
                <button class="btn btn-primary btn-sm" onclick="document.getElementById('fin-form-wrap').style.display='block'; window.scrollTo(0,0);">+ Registrar Cobro</button>
            </div>
            <table>
                <thead><tr><th>Fecha</th><th>Concepto</th><th>Socio</th><th>Monto</th><th>Método</th><th>Estado</th></tr></thead>
                <tbody>
                    ${dashboardData.finances.length === 0 ? '<tr><td colspan="6" class="text-center p-lg">Sin transacciones — usa el botón Registrar Cobro</td></tr>' :
            dashboardData.finances.map(f => {
                const isInc = Number(f.amount) > 0;
                return `<tr>
                    <td>${new Date(f.created_at).toLocaleDateString('es-CL')}</td>
                    <td>${f.description || f.item_name || 'Servicio'}</td>
                    <td>${f.socio_nombre || '-'}</td>
                    <td class="font-700 ${isInc ? 'text-success' : 'text-error'}">${isInc ? '+' : ''}${fmt.format(Number(f.amount))}</td>
                    <td>${f.payment_method || '-'}</td>
                    <td><span class="badge badge-${f.status === 'Pagado' || f.status === 'success' ? 'success' : 'warning'}">${f.status === 'success' ? 'Pagado' : f.status || 'Pagado'}</span></td>
                </tr>`;
            }).join('')}
                </tbody>
            </table>
        </div>`;
}

async function guardarTransaccion(e) {
    e.preventDefault();
    const tipo = document.getElementById('fin-tipo').value;
    const rawMonto = parseFloat(document.getElementById('fin-monto').value);
    const monto = tipo === 'egreso' ? -rawMonto : rawMonto;
    const tx = {
        id: Date.now(), description: document.getElementById('fin-desc').value,
        amount: monto, payment_method: document.getElementById('fin-metodo').value,
        socio_nombre: document.getElementById('fin-socio').value,
        status: 'Pagado', created_at: document.getElementById('fin-fecha').value + 'T12:00:00Z'
    };
    try { await supabase.from('transactions').insert([{ description: tx.description, amount: tx.amount, payment_method: tx.payment_method, status: tx.status }]); } catch { /* offline */ }
    dashboardData.finances.unshift(tx);
    document.getElementById('fin-form-wrap').style.display = 'none';
    document.getElementById('fin-form').reset();
    showSection('finances');
    setTimeout(initializeCharts, 100);
    alert('Transacción registrada ✅');
}
window.guardarTransaccion = guardarTransaccion;

function renderCalendar(container) {
    container.innerHTML = `
        <!-- Add Class Form -->
        <div id="clase-form-wrap" style="display:none;" class="glass-card p-xl mb-lg">
            <h4 class="mb-lg" style="color:var(--primary);">Nueva Clase</h4>
            <form id="clase-form" onsubmit="guardarClase(event)">
                <div class="grid grid-cols-3 gap-md mb-md">
                    <div><label style="display:block;font-size:.8rem;color:var(--text-muted);margin-bottom:4px;">Nombre de la Clase</label>
                        <input id="cl-nombre" required placeholder="Pilates Reformer" style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;"></div>
                    <div><label style="display:block;font-size:.8rem;color:var(--text-muted);margin-bottom:4px;">Tipo</label>
                        <select id="cl-tipo" style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;">
                            <option value="pilates">Pilates</option><option value="gym">Gimnasio</option><option value="grupal">Grupal / HIIT</option><option value="personal">Entrenamiento Personal</option>
                        </select></div>
                    <div><label style="display:block;font-size:.8rem;color:var(--text-muted);margin-bottom:4px;">Instructor</label>
                        <input id="cl-instructor" required placeholder="María González" style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;"></div>
                    <div><label style="display:block;font-size:.8rem;color:var(--text-muted);margin-bottom:4px;">Horario</label>
                        <input id="cl-horario" type="time" required value="09:00" style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;"></div>
                    <div><label style="display:block;font-size:.8rem;color:var(--text-muted);margin-bottom:4px;">Cupos Máx.</label>
                        <input id="cl-cupos" type="number" required value="8" style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;"></div>
                    <div><label style="display:block;font-size:.8rem;color:var(--text-muted);margin-bottom:4px;">Días</label>
                        <select id="cl-dias" multiple style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:8px;color:white;height:80px;">
                            <option value="Lun" selected>Lunes</option><option value="Mar">Martes</option><option value="Mie">Miércoles</option>
                            <option value="Jue">Jueves</option><option value="Vie">Viernes</option><option value="Sab">Sábado</option><option value="Dom">Domingo</option>
                        </select></div>
                </div>
                <p style="font-size:.7rem;color:var(--text-muted);margin-bottom:1rem;">💡 Mantén Ctrl presionado para seleccionar múltiples días</p>
                <div class="flex gap-md">
                    <button type="submit" class="btn btn-primary">Guardar Clase</button>
                    <button type="button" class="btn btn-secondary" onclick="document.getElementById('clase-form-wrap').style.display='none';">Cancelar</button>
                </div>
            </form>
        </div>

        <!-- Class List -->
        <div class="flex justify-between items-center mb-lg">
            <h3>Calendario de Clases (${dashboardData.classes.length})</h3>
            <button class="btn btn-primary btn-sm" onclick="document.getElementById('clase-form-wrap').style.display='block';">+ Nueva Clase</button>
        </div>
        <div class="glass-card overflow-hidden mb-lg">
            <table>
                <thead><tr><th>Hora</th><th>Clase</th><th>Tipo</th><th>Instructor</th><th>Cupos</th><th>Ocupación</th><th>Acciones</th></tr></thead>
                <tbody>
                    ${dashboardData.classes.length === 0 ? '<tr><td colspan="7" class="text-center p-lg">Sin clases — agrega una con el botón superior</td></tr>' :
            dashboardData.classes.map((c, idx) => {
                const max = c.cupos_max || 8;
                const occ = c.cupos_ocupados || 0;
                const pct = Math.min(100, Math.round(occ / max * 100));
                const color = pct >= 100 ? 'var(--error)' : pct >= 75 ? 'var(--warning)' : 'var(--success)';
                return `<tr>
                    <td style="font-weight:700;">${c.horario ? c.horario.substring(0, 5) : '--:--'}</td>
                    <td>${c.nombre}</td>
                    <td><span style="background:var(--primary)22;color:var(--primary);padding:2px 8px;border-radius:4px;font-size:.7rem;font-weight:700;text-transform:uppercase;">${c.tipo}</span></td>
                    <td>${c.instructor}</td>
                    <td>${occ}/${max}</td>
                    <td><div style="display:flex;align-items:center;gap:.5rem;">
                        <div style="width:80px;height:6px;background:var(--bg-tertiary);border-radius:999px;"><div style="width:${pct}%;height:100%;background:${color};border-radius:999px;"></div></div>
                        <span style="font-size:.75rem;color:${color};font-weight:700;">${pct}%</span>
                    </div></td>
                    <td>
                        <button class="btn btn-secondary btn-sm" onclick="editarClase(${idx})">Editar</button>
                        <button class="btn btn-sm" style="background:var(--error)22;color:var(--error);" onclick="eliminarClase(${idx})">✕</button>
                    </td>
                </tr>`;
            }).join('')}
                </tbody>
            </table>
        </div>`;
}

async function guardarClase(e) {
    e.preventDefault();
    const diasSel = Array.from(document.getElementById('cl-dias').selectedOptions).map(o => o.value);
    const clase = {
        id: Date.now(), nombre: document.getElementById('cl-nombre').value,
        tipo: document.getElementById('cl-tipo').value,
        instructor: document.getElementById('cl-instructor').value,
        horario: document.getElementById('cl-horario').value + ':00',
        cupos_max: parseInt(document.getElementById('cl-cupos').value),
        cupos_ocupados: 0, dias: diasSel
    };
    try { await supabase.from('clases').insert([{ nombre: clase.nombre, tipo: clase.tipo, instructor: clase.instructor, horario: clase.horario, cupos_max: clase.cupos_max, cupos_ocupados: 0 }]); } catch { /* offline */ }
    dashboardData.classes.push(clase);
    document.getElementById('clase-form-wrap').style.display = 'none';
    document.getElementById('clase-form').reset();
    showSection('calendar');
    alert(`Clase "${clase.nombre}" agregada ✅`);
}

function editarClase(idx) {
    const c = dashboardData.classes[idx];
    const nuevoNombre = prompt('Nombre de la clase:', c.nombre);
    const nuevoHorario = prompt('Horario (HH:MM):', c.horario ? c.horario.substring(0, 5) : '09:00');
    const nuevoCupos = prompt('Cupos máximos:', c.cupos_max);
    if (nuevoNombre) c.nombre = nuevoNombre;
    if (nuevoHorario) c.horario = nuevoHorario + ':00';
    if (nuevoCupos) c.cupos_max = parseInt(nuevoCupos);
    showSection('calendar');
}

function eliminarClase(idx) {
    if (confirm(`¿Eliminar la clase "${dashboardData.classes[idx].nombre}"?`)) {
        dashboardData.classes.splice(idx, 1);
        showSection('calendar');
    }
}
window.guardarClase = guardarClase;
window.editarClase = editarClase;
window.eliminarClase = eliminarClase;

function renderWaitlist(container) {
    if (dashboardData.waitlist.length === 0) {
        container.innerHTML = '<div class="glass-card p-xl text-center"><p class="text-muted">No hay socios en lista de espera actualmente.</p></div>';
        return;
    }

    container.innerHTML = `
        <div class="glass-card">
            <table>
                <thead>
                    <tr>
                        <th>Socio</th>
                        <th>Clase</th>
                        <th>Fecha Solicitud</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    ${dashboardData.waitlist.map(w => `
                        <tr>
                            <td>${w.socio.nombre}</td>
                            <td>${w.clase.nombre} • ${w.clase.horario.substring(0, 5)}</td>
                            <td>${new Date(w.created_at).toLocaleDateString('es-CL')}</td>
                            <td>
                                <button class="btn btn-primary btn-sm" onclick="promoteFromWaitlist('${w.id}')">Asignar Cupo</button>
                                <button class="btn btn-secondary btn-sm" onclick="removeFromWaitlist('${w.id}')">Quitar</button>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    `;
}

async function handleCheckIn(classId, className) {
    const user = window.getCurrentUser ? window.getCurrentUser() : { role: 'admin' };

    // Check-in logic...
    if (confirm(`¿Confirmar asistencia para ${className}?`)) {
        alert(`Check-in realizado para clase de ${className}`);
    }
}

async function promoteFromWaitlist(waitlistId) {
    const item = dashboardData.waitlist.find(w => w.id === waitlistId);
    if (!item) return;

    if (confirm(`¿Promover a ${item.socio.nombre} a la clase de ${item.clase.nombre}?`)) {
        try {
            // 1. Create reservation
            const { error: resError } = await supabase
                .from('reservas')
                .insert([{
                    socio_id: item.socio_id,
                    clase_id: item.clase_id,
                    fecha: item.fecha
                }]);

            if (resError) throw resError;

            // 2. Remove from waitlist
            const { error: delError } = await supabase
                .from('lista_espera')
                .delete()
                .eq('id', waitlistId);

            if (delError) throw delError;

            alert('Socio promovido con éxito ✅');
            fetchDashboardData();
        } catch (err) {
            console.error('Error promoting:', err);
            alert('Error al promover socio');
        }
    }
}

async function removeFromWaitlist(waitlistId) {
    if (confirm('¿Quitar de la lista de espera?')) {
        await supabase.from('lista_espera').delete().eq('id', waitlistId);
        fetchDashboardData();
    }
}

async function handleNewLead() {
    document.getElementById('lead-form-wrap') && (document.getElementById('lead-form-wrap').style.display = 'block');
}

function formatCurrency(amount) {
    return new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP', minimumFractionDigits: 0 }).format(amount);
}

async function showNewMemberModal() {
    const nombre = prompt('Nombre del Socio:');
    const email = prompt('Email:');
    if (!nombre || !email) return;

    let planType = prompt('Tipo de Plan:\n1 = Pilates\n2 = Gimnasio\n\nIngresa 1 o 2:');
    let planName = '';
    let clasesRestantes = 0;

    if (planType === '1') {
        let freq = prompt('Frecuencia Pilates (1, 2, 3 o 4 veces por semana):');
        freq = parseInt(freq) || 2;
        planName = `Pilates ${freq}x Semanal`;
        clasesRestantes = freq * 4;
    } else {
        planName = 'Plan Gimnasio';
        clasesRestantes = 999;
    }

    const newMember = {
        id: Date.now(),
        nombre, email, plan: planName,
        estado: 'Activo',
        clases_restantes: clasesRestantes,
        fecha_vencimiento: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
    };

    try {
        const { error } = await supabase.from('socios').insert([{ nombre, email, plan: planName, estado: 'Activo', clases_restantes: clasesRestantes, fecha_vencimiento: newMember.fecha_vencimiento }]);
        if (error) throw error;
        alert('Socio registrado en Supabase ✅');
        fetchDashboardData();
    } catch (err) {
        // Fallback: save locally
        dashboardData.members.push(newMember);
        alert(`Socio "${nombre}" registrado localmente ✅\n(Sin conexión a Supabase)`);
        showSection('members');
    }
}


window.getPlansData = function() {
    const defaultPlans = DUMMY_DATA.plans;
    if (!localStorage.getItem('aura_plans')) {
        localStorage.setItem('aura_plans', JSON.stringify(defaultPlans));
    }
    return JSON.parse(localStorage.getItem('aura_plans'));
};

function renderPlans(container) {
    const plansData = window.getPlansData();
    container.innerHTML = `
        <div class="grid grid-cols-2 gap-lg mb-lg">
            <div class="glass-card p-lg">
                <div class="flex justify-between items-center mb-md">
                    <h3 class="text-primary">Pilates</h3>
                    <button class="btn btn-primary btn-sm" onclick="window.mostrarModalNuevoPlan('pilates')">+ Añadir</button>
                </div>
                <div class="grid gap-md">
                    ${plansData.pilates.map(p => `
                        <div class="flex justify-between items-center p-md bg-white-05 rounded-xl border border-white-05 plan-editor-card">
                            <div>
                                <p class="font-600">${p.name}</p>
                                <p class="text-xs text-muted">${p.duration} mes(es) • ${p.freq} vez/sem</p>
                            </div>
                            <div class="flex items-center gap-md">
                                <div class="flex items-center gap-sm">
                                    <span class="text-xs opacity-60">CLP</span>
                                    <input type="number" class="price-input" value="${p.price}" onchange="updatePlanPrice('pilates', '${p.id}', this.value)">
                                </div>
                                <button class="btn btn-sm" style="background:var(--error)22;color:var(--error);padding:0.25rem 0.5rem;" onclick="eliminarPlan('pilates', '${p.id}')">✕</button>
                            </div>
                        </div>
                    `).join('')}
                    ${plansData.pilates.length === 0 ? '<p class="text-muted text-sm my-md">No hay planes de Pilates</p>' : ''}
                </div>
            </div>
            <div class="glass-card p-lg">
                <div class="flex justify-between items-center mb-md">
                    <h3 class="text-success">Gimnasio & Otros</h3>
                    <button class="btn btn-primary btn-sm" onclick="window.mostrarModalNuevoPlan('gym')">+ Añadir</button>
                </div>
                <div class="grid gap-md">
                    ${plansData.gym.map(p => `
                        <div class="flex justify-between items-center p-md bg-white-05 rounded-xl border border-white-05 plan-editor-card">
                            <div>
                                <p class="font-600">${p.name}</p>
                                <p class="text-xs text-muted">${p.duration} mes(es)</p>
                            </div>
                            <div class="flex items-center gap-md">
                                <div class="flex items-center gap-sm">
                                    <span class="text-xs opacity-60">CLP</span>
                                    <input type="number" class="price-input" value="${p.price}" onchange="updatePlanPrice('gym', '${p.id}', this.value)">
                                </div>
                                <button class="btn btn-sm" style="background:var(--error)22;color:var(--error);padding:0.25rem 0.5rem;" onclick="eliminarPlan('gym', '${p.id}')">✕</button>
                            </div>
                        </div>
                    `).join('')}
                    ${plansData.gym.length === 0 ? '<p class="text-muted text-sm my-md">No hay planes de Gimnasio</p>' : ''}
                </div>
            </div>
        </div>

        <!-- Add Plan Modal (Hidden) -->
        <div id="modal-nuevo-plan" style="display:none; position:fixed; top:0; left:0; right:0; bottom:0; background:rgba(0,0,0,0.8); z-index:999; align-items:center; justify-content:center;">
            <div class="glass-card p-xl" style="width: 400px; max-width: 90%; position:relative;">
                <h3 class="mb-md text-primary">Crear Nuevo Plan</h3>
                <form onsubmit="guardarNuevoPlan(event)">
                    <div class="mb-sm">
                        <label class="text-xs text-muted">Tipo de Plan</label>
                        <select id="np-tipo" style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:8px;color:white;" required onchange="const c = document.getElementById('np-freq-container'); c.style.display = this.value === 'gym' ? 'none' : 'block';">
                            <option value="pilates">Pilates</option>
                            <option value="gym">Gimnasio / Otros</option>
                        </select>
                    </div>
                    <div class="mb-sm">
                        <label class="text-xs text-muted">Nombre del Plan</label>
                        <input id="np-nombre" style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:8px;color:white;" required placeholder="Ej: Pilates Mensual 2x">
                    </div>
                    <div class="mb-sm">
                        <label class="text-xs text-muted">Precio (CLP)</label>
                        <input type="number" id="np-precio" style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:8px;color:white;" required placeholder="Ej: 45000">
                    </div>
                    <div class="grid grid-cols-2 gap-sm mb-lg">
                        <div id="np-freq-container">
                            <label class="text-xs text-muted">Frecuencia (veces/semana)</label>
                            <input type="number" id="np-freq" value="1" style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:8px;color:white;">
                        </div>
                        <div>
                            <label class="text-xs text-muted">Duración (meses)</label>
                            <input type="number" id="np-duracion" value="1" style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:8px;color:white;" required>
                        </div>
                    </div>
                    <div class="flex gap-sm justify-end">
                        <button type="button" class="btn btn-secondary" onclick="document.getElementById('modal-nuevo-plan').style.display='none'">Cancelar</button>
                        <button type="submit" class="btn btn-primary">Guardar Plan</button>
                    </div>
                </form>
            </div>
        </div>
    `;
}

window.mostrarModalNuevoPlan = function(tipo) {
    if(tipo) document.getElementById('np-tipo').value = tipo;
    const isGym = tipo === 'gym';
    document.getElementById('np-freq-container').style.display = isGym ? 'none' : 'block';
    if(isGym) document.getElementById('np-freq').value = "0";

    document.getElementById('np-nombre').value = "";
    document.getElementById('np-precio').value = "";
    document.getElementById('modal-nuevo-plan').style.display = 'flex';
};

window.guardarNuevoPlan = function(e) {
    e.preventDefault();
    const tipo = document.getElementById('np-tipo').value;
    const nombre = document.getElementById('np-nombre').value;
    const price = parseInt(document.getElementById('np-precio').value);
    const freq = parseInt(document.getElementById('np-freq').value) || null;
    const duration = parseInt(document.getElementById('np-duracion').value) || 1;
    
    const plansData = window.getPlansData();
    const newId = tipo.charAt(0) + Date.now();
    
    plansData[tipo].push({
        id: newId,
        name: nombre,
        price,
        freq,
        duration
    });
    
    localStorage.setItem('aura_plans', JSON.stringify(plansData));
    document.getElementById('modal-nuevo-plan').style.display = 'none';
    showSection('plans');
};

function updatePlanPrice(type, id, newPrice) {
    const plansData = window.getPlansData();
    const plan = plansData[type].find(p => p.id === id);
    if (plan) plan.price = parseInt(newPrice);
    localStorage.setItem('aura_plans', JSON.stringify(plansData));
}

window.eliminarPlan = function(type, id) {
    if(confirm('¿Seguro quieres eliminar este plan?')) {
        const plansData = window.getPlansData();
        plansData[type] = plansData[type].filter(p => p.id !== id);
        localStorage.setItem('aura_plans', JSON.stringify(plansData));
        showSection('plans');
    }
};

window.savePlanConfig = function() {
    alert('Los precios y planes se actualizan automáticamente. ✅');
};

function renderEvaluations(container) {
    // Load saved evaluations from localStorage
    const saved = JSON.parse(localStorage.getItem('aura_evaluations') || '[]');

    container.innerHTML = `
        <div class="flex justify-between items-center mb-lg">
            <h3>Evaluaciones Físicas</h3>
            <button class="btn btn-primary" onclick="showEvalForm()" id="btn-nueva-eval">+ Nueva Evaluación</button>
        </div>

        <!-- Form (hidden by default) -->
        <div id="eval-form-container" style="display:none;" class="glass-card p-xl mb-lg">
            <h4 class="mb-lg" style="color:var(--primary);">Nueva Evaluación Antropométrica</h4>
            <form id="eval-form" onsubmit="guardarEvaluacion(event)">
                <div class="grid grid-cols-2 gap-lg mb-lg">
                    <div>
                        <label style="display:block;font-size:0.8rem;color:var(--text-muted);margin-bottom:6px;">Socio</label>
                        <select id="eval-socio" style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;font-size:0.9rem;" required>
                            <option value="">Seleccionar socio...</option>
                            ${dashboardData.members.map(m => `<option value="${m.id}">${m.nombre}</option>`).join('')}
                        </select>
                    </div>
                    <div>
                        <label style="display:block;font-size:0.8rem;color:var(--text-muted);margin-bottom:6px;">Fecha</label>
                        <input type="date" id="eval-fecha" value="${new Date().toISOString().split('T')[0]}" style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;font-size:0.9rem;" required>
                    </div>
                </div>

                <p style="font-size:0.75rem;color:var(--primary);text-transform:uppercase;letter-spacing:1px;margin-bottom:1rem;font-weight:700;">Composición Corporal</p>
                <div class="grid grid-cols-3 gap-md mb-lg">
                    ${[
            { id: 'peso', label: 'Peso (kg)', ph: '70.5' },
            { id: 'altura', label: 'Altura (cm)', ph: '165' },
            { id: 'imc', label: 'IMC (auto)', ph: 'Auto' },
            { id: 'grasa', label: '% Grasa Corporal', ph: '22' },
            { id: 'musculo', label: '% Masa Muscular', ph: '40' },
            { id: 'agua', label: '% Agua Corporal', ph: '55' }
        ].map(f => `
                        <div>
                            <label style="display:block;font-size:0.8rem;color:var(--text-muted);margin-bottom:4px;">${f.label}</label>
                            <input type="number" step="0.1" id="eval-${f.id}" placeholder="${f.ph}" ${f.id === 'imc' ? 'readonly' : ''}
                                style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;font-size:0.9rem;"
                                ${f.id === 'peso' || f.id === 'altura' ? 'oninput="calcularIMC()"' : ''}>
                        </div>
                    `).join('')}
                </div>

                <p style="font-size:0.75rem;color:var(--primary);text-transform:uppercase;letter-spacing:1px;margin-bottom:1rem;font-weight:700;">Medidas Antropométricas (cm)</p>
                <div class="grid grid-cols-4 gap-md mb-lg">
                    ${[
            { id: 'cintura', label: 'Cintura' }, { id: 'cadera', label: 'Cadera' }, { id: 'pecho', label: 'Pecho' }, { id: 'cuello', label: 'Cuello' },
            { id: 'brazo_d', label: 'Brazo Der.' }, { id: 'brazo_i', label: 'Brazo Izq.' }, { id: 'muslo_d', label: 'Muslo Der.' }, { id: 'muslo_i', label: 'Muslo Izq.' },
            { id: 'pantorrilla', label: 'Pantorrilla' }, { id: 'hombros', label: 'Hombros' }, { id: 'torax', label: 'Tórax' }, { id: 'tobillo', label: 'Tobillo' }
        ].map(f => `
                        <div>
                            <label style="display:block;font-size:0.75rem;color:var(--text-muted);margin-bottom:4px;">${f.label}</label>
                            <input type="number" step="0.1" id="eval-${f.id}"
                                style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:8px;color:white;font-size:0.85rem;">
                        </div>
                    `).join('')}
                </div>

                <p style="font-size:0.75rem;color:var(--primary);text-transform:uppercase;letter-spacing:1px;margin-bottom:1rem;font-weight:700;">Nivel de Condición Física</p>
                <div class="grid grid-cols-2 gap-md mb-lg">
                    <div>
                        <label style="display:block;font-size:0.8rem;color:var(--text-muted);margin-bottom:4px;">Nivel General</label>
                        <select id="eval-nivel" style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;font-size:0.9rem;">
                            <option>Principiante</option><option>Intermedio</option><option>Avanzado</option><option>Élite</option>
                        </select>
                    </div>
                    <div>
                        <label style="display:block;font-size:0.8rem;color:var(--text-muted);margin-bottom:4px;">Objetivo</label>
                        <select id="eval-objetivo" style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;font-size:0.9rem;">
                            <option>Pérdida de peso</option><option>Ganancia muscular</option><option>Tonificación</option><option>Flexibilidad</option><option>Rendimiento</option>
                        </select>
                    </div>
                    <div style="grid-column:1/-1;">
                        <label style="display:block;font-size:0.8rem;color:var(--text-muted);margin-bottom:4px;">Observaciones</label>
                        <textarea id="eval-obs" rows="3" style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;font-size:0.9rem;resize:vertical;"></textarea>
                    </div>
                </div>

                <div class="flex gap-md">
                    <button type="submit" class="btn btn-primary">Guardar Evaluación</button>
                    <button type="button" class="btn btn-secondary" onclick="document.getElementById('eval-form-container').style.display='none';">Cancelar</button>
                </div>
            </form>
        </div>

        <!-- Evaluations List -->
        <div id="eval-list">
            ${saved.length === 0
            ? '<div class="glass-card p-xl text-center"><p class="text-muted">No hay evaluaciones registradas. Presiona "+ Nueva Evaluación" para comenzar.</p></div>'
            : `<div class="glass-card overflow-hidden">
                    <table>
                        <thead><tr>
                            <th>Socio</th><th>Fecha</th><th>Peso</th><th>IMC</th><th>% Grasa</th><th>% Músculo</th><th>Nivel</th><th>Acciones</th>
                        </tr></thead>
                        <tbody>
                            ${saved.map((e, i) => `
                            <tr>
                                <td><strong>${e.socio}</strong></td>
                                <td>${e.fecha}</td>
                                <td>${e.peso || '-'} kg</td>
                                <td><span class="badge badge-${parseFloat(e.imc) < 25 ? 'success' : parseFloat(e.imc) < 30 ? 'warning' : 'error'}">${e.imc || '-'}</span></td>
                                <td>${e.grasa || '-'}%</td>
                                <td>${e.musculo || '-'}%</td>
                                <td><span class="badge badge-info">${e.nivel}</span></td>
                                <td><button class="btn btn-secondary btn-sm" onclick="verEvaluacion(${i})">Ver</button> <button class="btn btn-sm" style="background:var(--error);color:white;" onclick="eliminarEvaluacion(${i})">✕</button></td>
                            </tr>`).join('')}
                        </tbody>
                    </table>
                </div>`
        }
        </div>
    `;
}

function showEvalForm() {
    const fc = document.getElementById('eval-form-container');
    if (fc) fc.style.display = fc.style.display === 'none' ? 'block' : 'none';
}

function calcularIMC() {
    const peso = parseFloat(document.getElementById('eval-peso')?.value);
    const altura = parseFloat(document.getElementById('eval-altura')?.value);
    if (peso > 0 && altura > 0) {
        const imc = (peso / Math.pow(altura / 100, 2)).toFixed(1);
        const el = document.getElementById('eval-imc');
        if (el) el.value = imc;
    }
}

function guardarEvaluacion(e) {
    e.preventDefault();
    const socioId = document.getElementById('eval-socio').value;
    const socio = dashboardData.members.find(m => m.id == socioId);
    if (!socio) return alert('Selecciona un socio.');

    const eval_data = {
        socio: socio.nombre,
        socio_id: socioId,
        fecha: document.getElementById('eval-fecha').value,
        peso: document.getElementById('eval-peso').value,
        altura: document.getElementById('eval-altura').value,
        imc: document.getElementById('eval-imc').value,
        grasa: document.getElementById('eval-grasa').value,
        musculo: document.getElementById('eval-musculo').value,
        agua: document.getElementById('eval-agua').value,
        cintura: document.getElementById('eval-cintura').value,
        cadera: document.getElementById('eval-cadera').value,
        pecho: document.getElementById('eval-pecho').value,
        cuello: document.getElementById('eval-cuello').value,
        brazo_d: document.getElementById('eval-brazo_d').value,
        brazo_i: document.getElementById('eval-brazo_i').value,
        muslo_d: document.getElementById('eval-muslo_d').value,
        muslo_i: document.getElementById('eval-muslo_i').value,
        pantorrilla: document.getElementById('eval-pantorrilla').value,
        hombros: document.getElementById('eval-hombros').value,
        torax: document.getElementById('eval-torax').value,
        tobillo: document.getElementById('eval-tobillo').value,
        nivel: document.getElementById('eval-nivel').value,
        objetivo: document.getElementById('eval-objetivo').value,
        obs: document.getElementById('eval-obs').value,
        created_at: new Date().toISOString()
    };

    const saved = JSON.parse(localStorage.getItem('aura_evaluations') || '[]');
    saved.unshift(eval_data);
    localStorage.setItem('aura_evaluations', JSON.stringify(saved));

    alert('Evaluación guardada ✅');
    // Re-render
    const dyn = document.getElementById('dynamic-content');
    if (dyn) renderEvaluations(dyn);
}

function verEvaluacion(index) {
    const saved = JSON.parse(localStorage.getItem('aura_evaluations') || '[]');
    const ev = saved[index];
    if (!ev) return;
    alert(`📋 Evaluación de ${ev.socio} (${ev.fecha})

Peso: ${ev.peso} kg | Altura: ${ev.altura} cm | IMC: ${ev.imc}
Grasa: ${ev.grasa}% | Músculo: ${ev.musculo}% | Agua: ${ev.agua}%
──────────────────────
Cintura: ${ev.cintura} | Cadera: ${ev.cadera} | Pecho: ${ev.pecho}
Brazo D: ${ev.brazo_d} | Brazo I: ${ev.brazo_i}
Muslo D: ${ev.muslo_d} | Muslo I: ${ev.muslo_i}
──────────────────────
Nivel: ${ev.nivel} | Objetivo: ${ev.objetivo}
Observaciones: ${ev.obs || 'Ninguna'}`);
}

function eliminarEvaluacion(index) {
    if (!confirm('¿Eliminar esta evaluación?')) return;
    const saved = JSON.parse(localStorage.getItem('aura_evaluations') || '[]');
    saved.splice(index, 1);
    localStorage.setItem('aura_evaluations', JSON.stringify(saved));
    const dyn = document.getElementById('dynamic-content');
    if (dyn) renderEvaluations(dyn);
}

function updatePlanPrice(type, id, newPrice) {
    const plan = DUMMY_DATA.plans[type].find(p => p.id === id);
    if (plan) plan.price = parseInt(newPrice);
    console.log(`Updated price for ${id}: ${newPrice}`);
}

function savePlanConfig() {
    alert('Configuración de planes guardada exitosamente ✅');
}

// Removed duplicate applyRoleAccess function. This is now consolidated at the top.

async function handleLogout() {
    if (confirm('¿Estás seguro que deseas cerrar sesión?')) {
        if (window.logout) {
            window.logout();
        } else {
            window.location.href = 'login.html';
        }
    }
}

window.handleCheckIn = handleCheckIn;
window.promoteFromWaitlist = promoteFromWaitlist;
window.removeFromWaitlist = removeFromWaitlist;
window.showSection = showSection;
window.handleNewLead = handleNewLead;
window.showNewMemberModal = showNewMemberModal;
window.updatePlanPrice = updatePlanPrice;
window.savePlanConfig = savePlanConfig;
window.handleLogout = handleLogout;
window.showEvalForm = showEvalForm;
window.guardarEvaluacion = guardarEvaluacion;
window.calcularIMC = calcularIMC;
window.verEvaluacion = verEvaluacion;
window.eliminarEvaluacion = eliminarEvaluacion;

/* ============================================================
   NEW MODULE: ASISTENCIA
============================================================ */
function renderAttendance(container) {
    container.innerHTML = `
        <div class="flex gap-sm mb-lg border-b border-white-05" style="padding-bottom:1rem;">
            <button id="tab-att-gen" class="btn btn-primary" onclick="setAttendanceTab('general')">Asistencia General</button>
            <button id="tab-att-coach" class="btn btn-secondary" onclick="setAttendanceTab('coach')">Pasar Lista (Coach)</button>
            <button id="tab-att-rep" class="btn btn-secondary" onclick="setAttendanceTab('report')">Reporte Coaches</button>
        </div>
        <div id="attendance-content"></div>
    `;
    setTimeout(() => setAttendanceTab('general'), 0);
}

window.setAttendanceTab = function(tab) {
    document.getElementById('tab-att-gen').className = 'btn ' + (tab === 'general' ? 'btn-primary' : 'btn-secondary');
    document.getElementById('tab-att-coach').className = 'btn ' + (tab === 'coach' ? 'btn-primary' : 'btn-secondary');
    document.getElementById('tab-att-rep').className = 'btn ' + (tab === 'report' ? 'btn-primary' : 'btn-secondary');
    
    const content = document.getElementById('attendance-content');
    if (!content) return;

    if (tab === 'general') renderAttendanceGeneral(content);
    else if (tab === 'coach') renderAttendanceCoachView(content);
    else if (tab === 'report') renderAttendanceReport(content);
};

function renderAttendanceGeneral(container) {
    const asistencias = JSON.parse(localStorage.getItem('asistencias') || '[]');
    container.innerHTML = `
        <div class="glass-card p-lg mb-lg">
            <h4 class="mb-md" style="color:var(--primary);">Registrar Asistencia Rápida</h4>
            <div class="grid grid-cols-4 gap-md">
                <select id="att-socio" style="background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;">
                    <option value="">Seleccionar Socio...</option>
                    ${dashboardData.members.map(m => `<option value="${m.nombre}">${m.nombre}</option>`).join('')}
                </select>
                <select id="att-clase" style="background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;">
                    <option value="">Seleccionar Clase...</option>
                    ${dashboardData.classes.map(c => `<option value="${c.nombre}">${c.nombre} (${c.horario ? c.horario.substring(0, 5) : '--:--'})</option>`).join('')}
                </select>
                <input id="att-fecha" type="date" value="${new Date().toISOString().split('T')[0]}" style="background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;">
                <button class="btn btn-primary" onclick="registrarAsistencia()">✓ Registrar Asistencia</button>
            </div>
        </div>

        <!-- Stats Row -->
        <div class="grid grid-cols-3 gap-lg mb-lg">
            <div class="card p-lg text-center">
                <p class="text-muted text-xs mb-sm">ASISTENCIAS HOY</p>
                <h3 style="color:var(--primary);">${asistencias.filter(a => a.fecha === new Date().toISOString().split('T')[0]).length}</h3>
            </div>
            <div class="card p-lg text-center">
                <p class="text-muted text-xs mb-sm">ASISTENCIAS ESTE MES</p>
                <h3 style="color:var(--success);">${asistencias.filter(a => new Date(a.fecha).getMonth() === new Date().getMonth()).length}</h3>
            </div>
            <div class="card p-lg text-center">
                <p class="text-muted text-xs mb-sm">TOTAL REGISTRADAS</p>
                <h3>${asistencias.length}</h3>
            </div>
        </div>

        <div class="glass-card">
            <div class="p-md border-b border-white-05">
                <h3>Historial de Asistencia (${asistencias.length})</h3>
            </div>
            <table>
                <thead><tr><th>Fecha</th><th>Socio</th><th>Clase</th><th>Hora Registro</th><th>Estado</th></tr></thead>
                <tbody>
                    ${asistencias.length === 0
            ? '<tr><td colspan="5" class="text-center p-lg">Sin asistencias — registra con el formulario superior</td></tr>'
            : asistencias.slice().reverse().map(a => `
                    <tr>
                        <td>${new Date(a.fecha + 'T12:00:00').toLocaleDateString('es-CL')}</td>
                        <td><strong>${a.socio}</strong></td>
                        <td>${a.clase}</td>
                        <td>${a.hora}</td>
                        <td><span class="badge badge-success">✅ Presente</span></td>
                    </tr>`).join('')}
                </tbody>
            </table>
        </div>`;
}

function registrarAsistencia() {
    const socio = document.getElementById('att-socio').value;
    const clase = document.getElementById('att-clase').value;
    const fecha = document.getElementById('att-fecha').value;
    if (!socio || !clase) { alert('Por favor selecciona socio y clase'); return; }
    guardarAsistLocal(socio, clase, fecha);
    setAttendanceTab('general');
    alert(`Asistencia de ${socio} registrada ✅`);
}

function guardarAsistLocal(socio, clase, fecha) {
    const asistencias = JSON.parse(localStorage.getItem('asistencias') || '[]');
    const now = new Date();
    asistencias.push({ id: Date.now(), socio, clase, fecha, hora: now.toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' }) });
    localStorage.setItem('asistencias', JSON.stringify(asistencias));
    const m = dashboardData.members.find(x => x.nombre === socio);
    if (m && m.clases_restantes !== 999 && m.clases_restantes > 0) m.clases_restantes--;
}
window.registrarAsistencia = registrarAsistencia;

function renderAttendanceCoachView(container) {
    const coaches = [...new Set(dashboardData.classes.map(c => c.instructor).filter(Boolean))];
    const userRole = window.getCurrentUser ? window.getCurrentUser().role : 'admin';
    const userName = window.getCurrentUser ? window.getCurrentUser().name : '';
    
    let coachOptions = '<option value="">Seleccionar Instructor...</option>';
    if (userRole === 'coach') {
        coachOptions = `<option value="${userName}">${userName}</option>`;
    } else {
        coachOptions += coaches.map(c => `<option value="${c}">${c}</option>`).join('');
    }

    container.innerHTML = `
        <div class="glass-card p-lg mb-lg">
            <h4 class="mb-md" style="color:var(--primary);">Pasar Lista por Instructor</h4>
            <div class="grid grid-cols-3 gap-md">
                <select id="coach-selector" onchange="loadCoachClasses()" style="background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;">
                    ${coachOptions}
                </select>
                <select id="coach-class-selector" onchange="loadCoachClassStudents()" style="background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;" disabled>
                    <option value="">Selecciona clase...</option>
                </select>
                <input id="coach-date" type="date" value="${new Date().toISOString().split('T')[0]}" onchange="loadCoachClassStudents()" style="background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;">
            </div>
        </div>
        <div id="coach-class-students">
            <div class="glass-card"><p class="text-center text-muted p-lg">Selecciona un instructor y una clase para ver los alumnos anotados.</p></div>
        </div>
    `;
    if (userRole === 'coach') {
        setTimeout(() => {
            const sel = document.getElementById('coach-selector');
            if(sel && sel.options.length > 1) {
                sel.selectedIndex = 1;
                loadCoachClasses();
            }
        }, 50);
    }
}

window.loadCoachClasses = function() {
    const coach = document.getElementById('coach-selector').value;
    const classSel = document.getElementById('coach-class-selector');
    if(!coach) {
        classSel.innerHTML = '<option value="">Selecciona clase...</option>';
        classSel.disabled = true;
        document.getElementById('coach-class-students').innerHTML = '<div class="glass-card"><p class="text-center text-muted p-lg">Selecciona un instructor y una clase para ver los alumnos anotados.</p></div>';
        return;
    }
    const classes = dashboardData.classes.filter(c => c.instructor === coach);
    classSel.innerHTML = '<option value="">Selecciona clase...</option>' + 
        classes.map(c => `<option value="${c.id}">${c.nombre} (${c.horario ? c.horario.substring(0,5) : ''})</option>`).join('');
    classSel.disabled = false;
    document.getElementById('coach-class-students').innerHTML = '<div class="glass-card"><p class="text-center text-muted p-lg">Clases cargadas. Ahora selecciona una clase.</p></div>';
};

window.loadCoachClassStudents = function() {
    const classId = document.getElementById('coach-class-selector').value;
    const fecha = document.getElementById('coach-date').value;
    const container = document.getElementById('coach-class-students');
    if(!classId) {
        container.innerHTML = '<div class="glass-card"><p class="text-center text-muted p-lg">Selecciona una clase primero.</p></div>'; return;
    }
    
    // Find Bookings for this class on this date
    let students = dashboardData.bookings.filter(b => b.clase_id == classId);
    
    // If no real bookings yet, fallback to dummy
    if(students.length === 0) {
        const dummyNames = ["Ana García", "Laura Torres", "Carlos Mendoza", "María Soto", "Juan Pérez", "Diego Ríos"];
        students = dummyNames.slice(0, Math.floor(Math.random()*4)+2).map((n, i) => ({ id: 'd'+i, socio: { nombre: n }, socio_nombre: n }));
    }

    const asistencias = JSON.parse(localStorage.getItem('asistencias') || '[]');
    const cl = dashboardData.classes.find(c => c.id == classId);
    const className = cl ? cl.nombre : '';

    container.innerHTML = `
        <div class="glass-card">
            <div class="p-md border-b border-white-05 flex justify-between items-center">
                <h3>Alumnos de la clase: ${className}</h3>
                <button class="btn btn-primary btn-sm" onclick="marcarTodosPresentes('${className}', '${fecha}')">✓ Marcar todos presentes</button>
            </div>
            <table>
                <thead><tr><th>Alumno</th><th>Estado</th><th>Acción</th></tr></thead>
                <tbody>
                    ${students.map(s => {
                        const name = s.socio ? s.socio.nombre : s.socio_nombre;
                        if(!name) return '';
                        const isPresent = asistencias.some(a => a.socio === name && a.clase === className && a.fecha === fecha);
                        return `
                        <tr>
                            <td><strong>${name}</strong></td>
                            <td>${isPresent ? '<span class="badge badge-success">✅ Asistió</span>' : '<span class="badge badge-warning">Pendiente</span>'}</td>
                            <td>
                                ${isPresent 
                                    ? `<button class="btn btn-secondary btn-sm" disabled>Registrado</button>`
                                    : `<button class="btn btn-primary btn-sm btn-mark-present" onclick="registrarCoachAsistencia('${name}', '${className}', '${fecha}')">✔ Presente</button>`}
                            </td>
                        </tr>`;
                    }).join('')}
                </tbody>
            </table>
        </div>
    `;
};

window.registrarCoachAsistencia = function(socio, clase, fecha) {
    guardarAsistLocal(socio, clase, fecha);
    loadCoachClassStudents(); // reload list
};

window.marcarTodosPresentes = function(clase, fecha) {
    if(!confirm('¿Marcar todos los alumnos como presentes?')) return;
    const rows = document.getElementById('coach-class-students').querySelectorAll('tbody tr');
    let count = 0;
    rows.forEach(r => {
        const btn = r.querySelector('.btn-mark-present');
        if(btn) {
            btn.click();
            count++;
        }
    });
    // no alert, click handles reload
};

function renderAttendanceReport(container) {
    const asistencias = JSON.parse(localStorage.getItem('asistencias') || '[]');
    const coaches = [...new Set(dashboardData.classes.map(c => c.instructor).filter(Boolean))];
    
    const today = new Date().toISOString().split('T')[0];
    const thisMonth = new Date().getMonth();
    
    const statsData = coaches.map(coach => {
        const classes = dashboardData.classes.filter(c => c.instructor === coach);
        const classNames = classes.map(c => c.nombre);
        const coachAsists = asistencias.filter(a => classNames.includes(a.clase));
        
        const asistHoy = coachAsists.filter(a => a.fecha === today).length;
        const asistMes = coachAsists.filter(a => new Date(a.fecha).getMonth() === thisMonth).length;
        
        let totalReservas = 0;
        classes.forEach(c => {
            let res = dashboardData.bookings.filter(b => b.clase_id === c.id).length;
            if(res === 0) res = (c.cupos_ocupados || 5) * 4; // default multiplier
            totalReservas += res;
        });
        
        const pct = totalReservas > 0 ? Math.round((asistMes / totalReservas) * 100) : 0;
        
        return { name: coach, classes: classes.length, asistHoy, asistMes, totalReservas, pct };
    });

    container.innerHTML = `
        <div class="glass-card mb-lg">
            <div class="p-md border-b border-white-05">
                <h3>Rendimiento y Asistencia por Instructor</h3>
            </div>
            <table>
                <thead>
                    <tr>
                        <th style="text-align:left;">Instructor</th>
                        <th>Clases a Cargo</th>
                        <th>Asistencias Hoy</th>
                        <th>Asistencias Mes</th>
                        <th>Cumplimiento (%)</th>
                    </tr>
                </thead>
                <tbody>
                    ${statsData.map(s => `
                    <tr>
                        <td><strong>${s.name}</strong></td>
                        <td align="center">${s.classes}</td>
                        <td align="center">${s.asistHoy}</td>
                        <td align="center">${s.asistMes} / ${s.totalReservas} reservas</td>
                        <td>
                            <div style="display:flex;align-items:center;gap:.5rem;justify-content:center;">
                                <div style="width:60px;height:6px;background:var(--bg-tertiary);border-radius:999px;">
                                    <div style="width:${Math.min(s.pct, 100)}%;height:100%;background:${s.pct >= 80 ? 'var(--success)' : s.pct >= 50 ? 'var(--warning)' : 'var(--error)'};border-radius:999px;"></div>
                                </div>
                                <span class="text-xs font-700 ${s.pct >= 80 ? 'text-success' : s.pct >= 50 ? 'text-warning' : 'text-error'}">${s.pct}%</span>
                            </div>
                        </td>
                    </tr>
                    `).join('')}
                    ${statsData.length === 0 ? '<tr><td colspan="5" class="text-center p-md">No hay instructores registrados.</td></tr>' : ''}
                </tbody>
            </table>
        </div>

        <div class="glass-card p-lg" style="height: 400px; display:flex; flex-direction:column;">
            <h3 class="mb-md">Comparativa: Reservas vs Asistencias por Instructor (Mes actual)</h3>
            <div style="flex:1; position:relative; width: 100%; height: 100%;">
                <canvas id="coachReportChart"></canvas>
            </div>
        </div>
    `;

    setTimeout(() => initCoachChart(statsData), 100);
}

function initCoachChart(statsData) {
    const ctx = document.getElementById('coachReportChart');
    if(!ctx) return;
    
    if(window.coachChartInstance) {
        window.coachChartInstance.destroy();
    }
    
    window.coachChartInstance = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: statsData.map(s => s.name),
            datasets: [
                {
                    label: 'Reservas Totales',
                    data: statsData.map(s => s.totalReservas),
                    backgroundColor: 'rgba(59, 130, 246, 0.7)',
                    borderRadius: 4
                },
                {
                    label: 'Asistencias Registradas',
                    data: statsData.map(s => s.asistMes),
                    backgroundColor: 'rgba(34, 197, 94, 0.8)',
                    borderRadius: 4
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { labels: { color: '#D4D4D8' } },
                tooltip: { backgroundColor: '#27272A', titleColor: '#FAFAFA', bodyColor: '#D4D4D8' }
            },
            scales: {
                y: { beginAtZero: true, grid: { color: 'rgba(255, 255, 255, 0.05)' }, ticks: { color: '#A1A1AA' } },
                x: { grid: { display: false }, ticks: { color: '#A1A1AA' } }
            }
        }
    });
}
window.registrarAsistencia = registrarAsistencia;

/* ============================================================
   NEW MODULE: COMUNICACIÓN
============================================================ */
function renderComunicacion(container) {
    container.innerHTML = `
        <!-- Message Composer -->
        <div class="glass-card p-xl mb-lg">
            <h4 class="mb-lg" style="color:var(--primary);">📣 Enviar Mensaje a Socios</h4>
            <div class="grid grid-cols-2 gap-md mb-md">
                <div>
                    <label style="display:block;font-size:.8rem;color:var(--text-muted);margin-bottom:4px;">Destinatarios</label>
                    <select id="msg-dest" style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;">
                        <option value="todos">Todos los Socios (${dashboardData.members.length})</option>
                        <option value="activos">Solo Activos (${dashboardData.members.filter(m => m.estado === 'Activo').length})</option>
                        <option value="vencidos">Vencidos / Por Renovar (${dashboardData.members.filter(m => m.estado === 'Vencido').length})</option>
                        <option value="leads">Leads Nuevos (${dashboardData.leads.filter(l => l.status === 'Nuevo').length})</option>
                    </select>
                </div>
                <div>
                    <label style="display:block;font-size:.8rem;color:var(--text-muted);margin-bottom:4px;">Canal</label>
                    <select id="msg-canal" style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;">
                        <option>📧 Email</option>
                        <option>📱 WhatsApp (simulado)</option>
                        <option>🔔 Push Notification (App)</option>
                    </select>
                </div>
                <div>
                    <label style="display:block;font-size:.8rem;color:var(--text-muted);margin-bottom:4px;">Asunto</label>
                    <input id="msg-asunto" placeholder="ej: Renovación pendiente, Clase especial..." style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;">
                </div>
                <div>
                    <label style="display:block;font-size:.8rem;color:var(--text-muted);margin-bottom:4px;">Plantilla rápida</label>
                    <select id="msg-template" onchange="aplicarTemplate(this.value)" style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;">
                        <option value="">Escribe tu propio mensaje...</option>
                        <option value="renovacion">🔄 Recordatorio de Renovación</option>
                        <option value="bienvenida">👋 Bienvenida</option>
                        <option value="clase_especial">🏋️ Clase Especial (Evento)</option>
                        <option value="cumple">🎂 Feliz Cumpleaños</option>
                    </select>
                </div>
            </div>
            <div class="mb-md">
                <label style="display:block;font-size:.8rem;color:var(--text-muted);margin-bottom:4px;">Mensaje</label>
                <textarea id="msg-body" rows="5" placeholder="Escribe tu mensaje aquí..." style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:12px;color:white;font-family:Inter,sans-serif;resize:vertical;"></textarea>
            </div>
            <div class="flex gap-md">
                <button class="btn btn-primary" onclick="enviarMensaje()">📤 Enviar Mensaje</button>
                <button class="btn btn-secondary" onclick="document.getElementById('msg-body').value='';">Limpiar</button>
            </div>
        </div>

        <!-- Quick Alerts -->
        <h3 class="mb-md">⚡ Alertas Automáticas Sugeridas</h3>
        <div class="grid grid-cols-3 gap-lg mb-lg">
            <div class="card p-lg" style="border-left:3px solid var(--warning);">
                <h4 style="color:var(--warning);margin-bottom:.5rem;">⏰ Por Vencer (7 días)</h4>
                <p class="text-muted text-xs mb-md">Socios con membresía próxima a vencer</p>
                <p class="font-700 text-xl mb-md">${dashboardData.members.filter(m => { const d = m.fecha_vencimiento ? (new Date(m.fecha_vencimiento + 'T12:00') - new Date()) / 86400000 : 999; return d >= 0 && d <= 7; }).length} socios</p>
                <button class="btn btn-sm btn-secondary" onclick="alertaRenovacion()">Enviar Recordatorio</button>
            </div>
            <div class="card p-lg" style="border-left:3px solid var(--error);">
                <h4 style="color:var(--error);margin-bottom:.5rem;">❌ Vencidos</h4>
                <p class="text-muted text-xs mb-md">Membresías ya vencidas sin renovar</p>
                <p class="font-700 text-xl mb-md">${dashboardData.members.filter(m => m.estado === 'Vencido').length} socios</p>
                <button class="btn btn-sm btn-secondary" onclick="alertaVencidos()">Contactar</button>
            </div>
            <div class="card p-lg" style="border-left:3px solid var(--info);">
                <h4 style="color:var(--info);margin-bottom:.5rem;">🆕 Leads Sin Contactar</h4>
                <p class="text-muted text-xs mb-md">Leads nuevos esperando seguimiento</p>
                <p class="font-700 text-xl mb-md">${dashboardData.leads.filter(l => l.status === 'Nuevo').length} leads</p>
                <button class="btn btn-sm btn-secondary" onclick="alertaLeads()">Enviar Bienvenida</button>
            </div>
        </div>

        <!-- Message History -->
        <div class="glass-card">
            <div class="p-md border-b border-white-05"><h3>Historial de Mensajes Enviados</h3></div>
            <div id="msg-history" style="padding:1rem;">
                ${(JSON.parse(localStorage.getItem('mensajes') || '[]')).length === 0
            ? '<p class="text-muted text-center p-lg">Sin mensajes enviados aún</p>'
            : JSON.parse(localStorage.getItem('mensajes') || '[]').slice().reverse().map(m => `
                    <div style="background:var(--bg-secondary);border-radius:8px;padding:.75rem;margin-bottom:.5rem;display:flex;justify-content:space-between;align-items:center;">
                        <div>
                            <p class="font-600">${m.asunto || '(sin asunto)'}</p>
                            <p class="text-xs text-muted">${m.canal} → ${m.dest} • ${new Date(m.fecha).toLocaleString('es-CL')}</p>
                        </div>
                        <span class="badge badge-success">Enviado</span>
                    </div>`).join('')}
            </div>
        </div>`;
}

const TEMPLATES = {
    renovacion: { asunto: 'Tu membresía está por vencer 🔔', body: 'Hola! Te recordamos que tu membresía en Aura Flow Fit vence próximamente.\n\nRenueva ahora y mantén tu rutina sin interrupciones. Contáctanos para más información.\n\n¡Te esperamos! 💪' },
    bienvenida: { asunto: '¡Bienvenida/o a Aura Flow Fit! 🌟', body: 'Hola! Nos alegra tenerte con nosotros en Aura Flow Fit.\n\nTu bienestar es nuestra prioridad. Cualquier duda, estamos aquí.\n\n¡Mucho ánimo en tu entrenamiento! 🏋️‍♀️' },
    clase_especial: { asunto: '¡Clase Especial este Sábado! 🏋️', body: 'Hola! Te invitamos a nuestra clase especial este sábado a las 10:00h.\n\nPlazas limitadas — reserva tu lugar respondiendo este mensaje.\n\n¡No te lo pierdas! 🔥' },
    cumple: { asunto: '¡Feliz Cumpleaños! 🎂', body: 'Hola! Hoy es un día especial y queremos felicitarte.\n\n¡Que cumplas muchos años más y sigas alcanzando tus metas! 🎉\n\nCon cariño, el equipo de Aura Flow Fit.' }
};

function aplicarTemplate(key) {
    if (!key) return;
    const t = TEMPLATES[key];
    document.getElementById('msg-asunto').value = t.asunto;
    document.getElementById('msg-body').value = t.body;
}

function enviarMensaje() {
    const asunto = document.getElementById('msg-asunto').value;
    const body = document.getElementById('msg-body').value;
    const canal = document.getElementById('msg-canal').value;
    const dest = document.getElementById('msg-dest').value;
    if (!body) { alert('Por favor escribe un mensaje'); return; }
    const mensajes = JSON.parse(localStorage.getItem('mensajes') || '[]');
    mensajes.push({ id: Date.now(), asunto, body, canal, dest, fecha: new Date().toISOString() });
    localStorage.setItem('mensajes', JSON.stringify(mensajes));
    showSection('comunicacion');
    alert(`✅ Mensaje enviado (simulado) a: ${dest}\nCanal: ${canal}`);
}

function alertaRenovacion() {
    document.getElementById('msg-dest') && (document.getElementById('msg-dest').value = 'vencidos');
    aplicarTemplate('renovacion');
    window.scrollTo(0, 0);
}
function alertaVencidos() { document.getElementById('msg-dest') && (document.getElementById('msg-dest').value = 'vencidos'); aplicarTemplate('renovacion'); window.scrollTo(0, 0); }
function alertaLeads() { document.getElementById('msg-dest') && (document.getElementById('msg-dest').value = 'leads'); aplicarTemplate('bienvenida'); window.scrollTo(0, 0); }

window.aplicarTemplate = aplicarTemplate;
window.enviarMensaje = enviarMensaje;
window.alertaRenovacion = alertaRenovacion;
window.alertaVencidos = alertaVencidos;
window.alertaLeads = alertaLeads;

/* ============================================================
   NEW MODULE: CONFIGURACIÓN COMPLETA
============================================================ */
function renderSettings(container) {
    const config = JSON.parse(localStorage.getItem('gym_config') || '{}');
    container.innerHTML = `
    <div class="grid grid-cols-2 gap-lg">

        <!-- Datos del Gym -->
        <div class="glass-card p-xl">
            <h4 class="mb-lg" style="color:var(--primary);">🏢 Datos del Gimnasio</h4>
            <div class="flex flex-col gap-md">
                ${cfgInput('cfg-nombre', 'Nombre del Gimnasio', config.nombre || 'Aura Flow Fit')}
                ${cfgInput('cfg-direccion', 'Dirección', config.direccion || 'Santiago, Chile')}
                ${cfgInput('cfg-telefono', 'Teléfono', config.telefono || '+56 9 1234 5678')}
                ${cfgInput('cfg-email', 'Email de contacto', config.email || 'hola@auraflowfit.cl')}
                ${cfgInput('cfg-web', 'Sitio Web', config.web || 'https://auraflowfit.cl')}
                <button class="btn btn-primary mt-md" onclick="guardarConfigGym()">Guardar Cambios</button>
            </div>
        </div>

        <!-- Horarios -->
        <div class="glass-card p-xl">
            <h4 class="mb-lg" style="color:var(--primary);">🕐 Horarios de Atención</h4>
            <div class="flex flex-col gap-sm">
                ${['Lunes-Viernes', 'Sábado', 'Domingo'].map((d, i) => `
                <div class="flex justify-between items-center p-sm" style="background:var(--bg-secondary);border-radius:8px;">
                    <span style="font-weight:600;min-width:120px;">${d}</span>
                    <input type="time" id="hora-inicio-${i}" value="${['07:00', '09:00', ''][i]}" style="background:var(--bg-tertiary);border:none;color:white;padding:4px 8px;border-radius:4px;">
                    <span class="text-muted">—</span>
                    <input type="time" id="hora-fin-${i}" value="${['22:00', '18:00', ''][i]}" style="background:var(--bg-tertiary);border:none;color:white;padding:4px 8px;border-radius:4px;">
                    <label style="display:flex;align-items:center;gap:.5rem;font-size:.8rem;color:var(--text-muted);">
                        <input type="checkbox" ${i < 2 ? 'checked' : ''} id="horario-activo-${i}"> Abierto
                    </label>
                </div>`).join('')}
                <button class="btn btn-primary mt-md" onclick="alert('Horarios guardados ✅')">Guardar Horarios</button>
            </div>
        </div>

        <!-- Notificaciones -->
        <div class="glass-card p-xl">
            <h4 class="mb-lg" style="color:var(--primary);">🔔 Notificaciones Automáticas</h4>
            <div class="flex flex-col gap-sm">
                ${[
            ['notif-venc', 'Alerta de membresía por vencer (7 días)', true],
            ['notif-cumple', 'Mensaje de cumpleaños automático', true],
            ['notif-clase', 'Recordatorio de clase 2h antes', true],
            ['notif-inasistencia', 'Alerta por 2 semanas sin asistencia', false],
            ['notif-pago', 'Confirmación de pago al socio', true],
            ['notif-bienvenida', 'Email de bienvenida a nuevos socios', true]
        ].map(([id, label, def]) => `
                <div class="flex justify-between items-center p-sm" style="background:var(--bg-secondary);border-radius:8px;">
                    <span style="font-size:.875rem;">${label}</span>
                    <label style="position:relative;display:inline-block;width:44px;height:24px;cursor:pointer;">
                        <input type="checkbox" id="${id}" ${def ? 'checked' : ''} style="opacity:0;width:0;height:0;" onchange="guardarNotifConfig()">
                        <span style="position:absolute;top:0;left:0;right:0;bottom:0;background:${def ? 'var(--primary)' : 'var(--bg-tertiary)'};border-radius:24px;transition:.3s;"></span>
                        <span style="position:absolute;content:'';height:18px;width:18px;left:3px;bottom:3px;background:white;border-radius:50%;transition:.3s;${def ? 'transform:translateX(20px)' : ''}"></span>
                    </label>
                </div>`).join('')}
            </div>
        </div>

        <!-- Staff Management -->
        <div class="glass-card p-xl">
            <h4 class="mb-lg" style="color:var(--primary);">👥 Gestión de Staff</h4>
            <table>
                <thead><tr><th>Nombre</th><th>Rol</th><th>Email</th><th>Acceso</th></tr></thead>
                <tbody>
                    ${[
            { nombre: 'Admin Principal', rol: 'Super Admin', email: 'admin@auraflow.cl', activo: true },
            { nombre: 'Instructora Pilates', rol: 'Instructor', email: 'pilates@auraflow.cl', activo: true },
            { nombre: 'Recepción', rol: 'Staff', email: 'recepcion@auraflow.cl', activo: true }
        ].map(s => `
                    <tr>
                        <td><strong>${s.nombre}</strong></td>
                        <td><span style="background:var(--primary)22;color:var(--primary);padding:2px 8px;border-radius:4px;font-size:.7rem;">${s.rol}</span></td>
                        <td class="text-muted text-xs">${s.email}</td>
                        <td><span class="badge badge-success">Activo</span></td>
                    </tr>`).join('')}
                </tbody>
            </table>
            <button class="btn btn-secondary btn-sm mt-md" onclick="alert('Función disponible con Supabase configurado')">+ Agregar Miembro Staff</button>
        </div>

        <!-- Integrations -->
        <div class="glass-card p-xl" style="grid-column:span 2;">
            <h4 class="mb-lg" style="color:var(--primary);">🔗 Integraciones</h4>
            <div class="grid grid-cols-4 gap-md">
                ${[
            { name: 'Supabase DB', status: 'connected', icon: '🗄️' },
            { name: 'n8n Automation', status: 'connected', icon: '⚙️' },
            { name: 'Flow.cl Pagos', status: 'pending', icon: '💳' },
            { name: 'WhatsApp API', status: 'pending', icon: '📱' },
            { name: 'Instagram DM', status: 'connected', icon: '📸' },
            { name: 'Google Calendar', status: 'pending', icon: '📅' },
            { name: 'Mailchimp', status: 'pending', icon: '📧' },
            { name: 'Analytics', status: 'pending', icon: '📊' }
        ].map(i => `
                <div style="background:var(--bg-secondary);border-radius:8px;padding:.75rem;text-align:center;border:1px solid ${i.status === 'connected' ? 'rgba(34,197,94,.3)' : 'var(--glass-border)'};">
                    <div style="font-size:1.5rem;margin-bottom:.5rem;">${i.icon}</div>
                    <p style="font-size:.8rem;font-weight:600;margin-bottom:.25rem;">${i.name}</p>
                    <span class="badge badge-${i.status === 'connected' ? 'success' : 'warning'}">${i.status === 'connected' ? 'Conectado' : 'Pendiente'}</span>
                </div>`).join('')}
            </div>
        </div>
    </div>`;
}

function cfgInput(id, label, value) {
    return `<div>
        <label style="display:block;font-size:.75rem;color:var(--text-muted);margin-bottom:4px;">${label}</label>
        <input id="${id}" value="${value}" style="width:100%;background:var(--bg-secondary);border:1px solid var(--glass-border);border-radius:8px;padding:10px;color:white;">
    </div>`;
}

function guardarConfigGym() {
    const config = {
        nombre: document.getElementById('cfg-nombre')?.value,
        direccion: document.getElementById('cfg-direccion')?.value,
        telefono: document.getElementById('cfg-telefono')?.value,
        email: document.getElementById('cfg-email')?.value,
        web: document.getElementById('cfg-web')?.value
    };
    localStorage.setItem('gym_config', JSON.stringify(config));
    alert('Configuración guardada ✅');
}

function guardarNotifConfig() {
    // saves notification state to localStorage
    const cfg = {};
    ['notif-venc', 'notif-cumple', 'notif-clase', 'notif-inasistencia', 'notif-pago', 'notif-bienvenida'].forEach(id => {
        const el = document.getElementById(id);
        if (el) cfg[id] = el.checked;
    });
    localStorage.setItem('notif_config', JSON.stringify(cfg));
}

window.guardarConfigGym = guardarConfigGym;
window.guardarNotifConfig = guardarNotifConfig;

